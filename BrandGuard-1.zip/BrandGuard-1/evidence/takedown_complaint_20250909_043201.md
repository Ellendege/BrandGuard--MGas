# Meta Takedown Request - M-Gas Kenya Brand Protection

**Generated:** 2025-09-09T04:32:01.477872  
**Complainant:** M-Gas Kenya Brand Protection Team  
**Grounds:** Trademark infringement, brand impersonation  

## Official Brand Reference
- **Page Name:** M-Gas
- **Entity Type:** Page 
- **Domain:** mgas.ke
- **Tagline:** "M-Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans."
- **Followers:** ~65,000

## Violating Entities (24 flagged)

### Facebook M-GAS COMPANY LTD 0787813153
- **URL:** https://www.facebook.com/groups/1416701029150257/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mr. M's gas giveaway with cars lined up
- **URL:** https://www.facebook.com/groups/1115480395465731/posts/1757254114621686/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Facebook M-Gas | Facebook
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-gas Kenya limited special offers
- **URL:** https://www.facebook.com/groups/957825675925241/posts/mgas-with-special-offers-12-bob-tu-dial-479-ku-register-for-m-gas-leo-pikakwabei/1271854731188999/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Look who’s happy! Our M-GAS 1st Anniver-saya Giveaway GRAND ...
- **URL:** https://www.facebook.com/mgaswincytrading/videos/look-whos-happy-our-m-gas-1st-anniver-saya-giveaway-grand-prize-winner-just-clai/329821892213407/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### charcoal stove promo is
- **URL:** https://www.facebook.com/groups/307365138803135/posts/charcoal-stove-promo-is-still-going-onprice-is-large-3100medium-2600small-1850no/708675682005410/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED CALL (0784860605) | ANGUKIA OFFERS ZA # ...
- **URL:** https://www.facebook.com/groups/653145767783316/posts/709698335461392/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ANOTHER GIVEAWAY CHALLENGE! 🎉 Want ...
- **URL:** https://www.facebook.com/groups/844685979256352/posts/2667103730347892/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook
- **URL:** https://www.facebook.com/61552820712644/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### NAKURU BUYING AND SELLING LEGIT SECOND HAND ITEMS ... - Facebook
- **URL:** https://www.facebook.com/groups/758358989008652/posts/1330249241819621/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Modern COAST ltd
- **URL:** https://www.facebook.com/people/Modern-COAST-ltd/100092931717354/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Huge moving sale. Make offers - Facebook
- **URL:** https://www.facebook.com/commerce/listing/1409929443454049/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Other posts - Facebook
- **URL:** https://www.facebook.com/groups/893208048514351/posts/1252343285934157/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Ukiwa na M-Gas budget ya gas is totally up to you. ...
- **URL:** https://www.facebook.com/MGasKenya/photos/ukiwa-na-m-gas-budget-ya-gas-is-totally-up-to-you-imagine-uneza-pika-ugali-nyama/603558722426328/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### We're hiring in Kitale! To apply, visit our careers website or ...
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1066779485029859/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### We are Hiring M-Gas is seeking motivated and dynamic ...
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### TODAY AS INUA JAMII WE OFFER PROMOTION TO ALL ...
- **URL:** https://www.facebook.com/groups/1264476181144677/posts/1683706582554966/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT> - Facebook Mgas kenya call 0750279398 - Facebook Genuine M-Gas Kenya L.T.D Helpline number 0101140606 | Facebook MGAS CUSTOMER SUPPORT - Facebook M-Gas Kenya | Facebook
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0755928849', '0750279398', '0750279398', '0101140606', '0736965095'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT - Facebook
- **URL:** https://www.facebook.com/groups/3644210639219066/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ELDORET TOWN DIRECTORY AND MARKETING AGENT | MGAS KENYA ...
- **URL:** https://www.facebook.com/groups/145297272312347/posts/2772549106253804/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0100594838'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers website...
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

