# Meta Takedown Request - M-Gas Kenya Brand Protection

**Generated:** 2025-09-09T05:24:11.300833  
**Complainant:** M-Gas Kenya Brand Protection Team  
**Grounds:** Trademark infringement, brand impersonation  

## Official Brand Reference
- **Page Name:** M-Gas
- **Entity Type:** Page 
- **Domain:** mgas.ke
- **Tagline:** "M-Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans."
- **Followers:** ~65,000

## Violating Entities (70 flagged)

### End of June Promo‼️ For every 1 tank of 11kg M-gas, you will ...
- **URL:** https://www.facebook.com/61573549531758/posts/end-of-june-promo️for-every-1-tank-of-11kg-m-gas-you-will-get-a-free-350ml-of-di/122135078354784984/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-gas Kenya limited special offers
- **URL:** https://www.facebook.com/groups/957825675925241/posts/mgas-with-special-offers-12-bob-tu-dial-479-ku-register-for-m-gas-leo-pikakwabei/1271854731188999/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...
- **URL:** https://www.facebook.com/groups/966324677961372/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0755471873'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mr. M's gas giveaway with cars lined up
- **URL:** https://www.facebook.com/groups/1115480395465731/posts/1757254114621686/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Original National ID ✅Safaricom Line ✅Deposit Of Ksh ...
- **URL:** https://www.facebook.com/groups/529071958129862/posts/1458314818538900/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us at 0800 721 ...
- **URL:** https://www.facebook.com/photo.php?fbid=571958102253057&id=100083166169294&set=a.162860166496188
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0111944487'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0111944487'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-gas now, Pay Later! Get 3 LPG refills for only 50 pesos per day ...
- **URL:** https://m.facebook.com/mgasconcepciontarlac/posts/m-gas-now-pay-laterget-3-lpg-refills-for-only-50-pesos-per-daycontact-us-0998583/122120095448783567/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0998583939'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Safaricom and M-Gas launched the revolutionary, prepaid ...
- **URL:** https://www.facebook.com/groups/954366519042739/posts/1170291037450285/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['+254107453715'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M GAS LIPA MOS MOS AGENT NUMBER CALL OR WHATSAPP ...
- **URL:** https://www.facebook.com/groups/1135545828247507/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103455159'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LTD AGENT CALL (0738002423/+ ...
- **URL:** https://www.facebook.com/groups/289318563672325/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['+254738286927'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers website...
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Albay Gas Corporation - Facebook Southern Gas Corporation Mindoro Branch | Calapan - Facebook MGAS NAGA MAIN - PALIT-TANGKE PROMO for only P930.00 ... M-Gas Franchising Philippines - GRAB THE CHANCE TO ... - Facebook GRAB THE CHANCE TO WIN A... - M-Gas Franchising Philippines Tierra Nevada Marketplace&Online Store | "One stop for all ... Be a part of the MGAS... - M-Gas Franchising Philippines
- **URL:** https://www.facebook.com/100063718218905/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-gas Kenya limited special offers
- **URL:** https://www.facebook.com/groups/957825675925241/posts/mgas-with-special-offers-12-bob-tu-dial-479-ku-register-for-m-gas-leo-pikakwabei/1271854731188999/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED (0752611017)
- **URL:** https://www.facebook.com/groups/957825675925241/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Look who’s happy! Our M-GAS 1st Anniver-saya Giveaway GRAND ...
- **URL:** https://www.facebook.com/mgaswincytrading/videos/look-whos-happy-our-m-gas-1st-anniver-saya-giveaway-grand-prize-winner-just-clai/329821892213407/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook M-gas Company Kenya - Facebook M Gas Kenya - Facebook M-GAS COMPANY LTD 0787813153 | Facebook M-GAS COMPANY 0787813153 - Facebook M-GAS KENYA LIMITED (0111944487) | Need assistance with your .....
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106926827', '0104778819', '0746447820', '0737559526', '0787813153', '0111944487'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Albay Gas Corporation - Facebook MGAS - Welcome to the Official Page of M-GAS TAYTAY! We ... M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook MGAS CUSTOMER SUPPORT - Facebook We are built and ready to support... - Alacrity Solutions
- **URL:** https://www.facebook.com/100063718218905/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-gas now, Pay Later! Get 3 LPG refills for only 50 pesos per day ...
- **URL:** https://m.facebook.com/mgasconcepciontarlac/posts/m-gas-now-pay-laterget-3-lpg-refills-for-only-50-pesos-per-daycontact-us-0998583/122120095448783567/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0998583939'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mascom Gas Trading Gas Refilling and Exchanges ...
- **URL:** https://www.facebook.com/groups/1651677148403782/posts/3990681181170022/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M GAS LIPA MOS MOS AGENT NUMBER CALL OR WHATSAPP ...
- **URL:** https://www.facebook.com/groups/1135545828247507/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103455159'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LTD AGENT CALL (0738002423/+ ...
- **URL:** https://www.facebook.com/groups/289318563672325/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['+254738286927'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas 📍: #Nairobi #Internship ⏱️ Deadline: 11th Aug ...
- **URL:** https://www.facebook.com/campusbizke/posts/-hr-digital-and-engagement-internship-m-gas-nairobi-internship-️-deadline-11th-a/1089234726681358/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### We are Hiring M-Gas is seeking motivated and dynamic ...
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### charcoal stove promo is
- **URL:** https://www.facebook.com/groups/307365138803135/posts/charcoal-stove-promo-is-still-going-onprice-is-large-3100medium-2600small-1850no/708675682005410/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M GAS KENYA PIKA BILA STRESS 2️⃣ Burners=@550 ...
- **URL:** https://www.facebook.com/groups/878566720242965/posts/1506157904150507/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0812350498'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED (0752611017)
- **URL:** https://www.facebook.com/groups/957825675925241/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M Gas Kenya offers gas delivery services
- **URL:** https://www.facebook.com/groups/1140874097101535/posts/1484917839363824/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0105030499'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ANOTHER GIVEAWAY CHALLENGE! 🎉 Want ...
- **URL:** https://www.facebook.com/groups/844685979256352/posts/2667103730347892/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M GAS KENYA PIKA BILA STRESS CALL US or ...
- **URL:** https://www.facebook.com/groups/1006090580858866/posts/1414235310044389/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M Gas Kenya - Facebook
- **URL:** https://www.facebook.com/61573685076479/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0746447820', '0737559526'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT - Facebook
- **URL:** https://www.facebook.com/groups/3644210639219066/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Gas Refilling ( *all types of gas cylinders)* 📌 Gas complete ...
- **URL:** https://www.facebook.com/groups/295474376849804/posts/706699862393918/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LTD AGENT CALL (0738002423/+ ...
- **URL:** https://www.facebook.com/groups/289318563672325/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0738002423', '+254738286927'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED 0738002423
- **URL:** https://www.facebook.com/groups/886437143029196/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0738002423', '0738002423', '+254738286927'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M GAS KENYA PIKA KILA WAKATI...CALL US 0100-337-463 OR ...
- **URL:** https://www.facebook.com/groups/1848134362617928/posts/1853188662112498/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...
- **URL:** https://www.facebook.com/groups/966324677961372/posts/1432480334679135/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### We are Hiring M-Gas is seeking motivated and dynamic ...
- **URL:** https://www.facebook.com/groups/359545889779700/posts/673762361691383/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-gas Lipa Mos's post
- **URL:** https://www.facebook.com/61558640182368/posts/we-are-hiring-in-nairobim-gas-is-seeking-motivated-and-dynamic-individuals-in-na/122160249488288006/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Modern COAST ltd
- **URL:** https://www.facebook.com/people/Modern-COAST-ltd/100092931717354/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Book your ticket know according to you ability. .NBVip class ...
- **URL:** https://www.facebook.com/100092931717354/posts/book-your-ticket-know-according-to-you-abilitynbvip-class-fares-will-vary-accord/106227452468613/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### SUNDAY SPECIAL OFFER🎊🎊 #MGAS HOT LINE ...
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1261574158883723/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS SAFARICOM TELL (SALES)0755415011
- **URL:** https://www.facebook.com/groups/4135103280045771/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Other posts - Facebook
- **URL:** https://www.facebook.com/groups/893208048514351/posts/1252343285934157/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas
- **URL:** https://www.facebook.com/story.php?story_fbid=605893695526164&id=100083166169294
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Usipatwe off-Guard! Here are the simple steps to have M- ...
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1122355772805563/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0111944487'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Ukiwa na M-Gas budget ya gas is totally up to you. ...
- **URL:** https://www.facebook.com/MGasKenya/photos/ukiwa-na-m-gas-budget-ya-gas-is-totally-up-to-you-imagine-uneza-pika-ugali-nyama/603558722426328/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### We are Hiring M-Gas is seeking motivated and dynamic ...
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### We're hiring in Kitale! To apply, visit our careers website or ...
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1066779485029859/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook M-Gas - We're hiring! To apply, visit our careers ... - Facebook M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... M-Gas - We're hiring in Kangemi! To apply, visit our careers ... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### TODAY AS INUA JAMII WE OFFER PROMOTION TO ALL ...
- **URL:** https://www.facebook.com/groups/1264476181144677/posts/1683706582554966/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### 0782946741 Mgas kenya imekuja na offer kibao
- **URL:** https://www.facebook.com/groups/2502306723286057/posts/2900756940107698/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0782946741'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | offer offers with only 550 ... - Facebook
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1025831539427440/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mgas Kenya are you interested What is the best
- **URL:** https://www.facebook.com/groups/abujacarbusiness/posts/2169648750202515/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ALMOST GIVEAWAY! 🏃🏃💨 💜💚 GET A QUALITY FOAM POA ...
- **URL:** https://www.facebook.com/groups/776036066350650/posts/1764225280865052/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0780163350'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT
- **URL:** https://www.facebook.com/groups/907555054290862/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS KENYA CALL 📞 OR WHATSAPP 0736965095 Low ...
- **URL:** https://www.facebook.com/groups/1327884598298290/posts/mgas-kenya-call-or-whatsapp-0736965095low-upfront-cost-low-initial-stove-deposit/1341723926914357/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0736965095', '0736965095'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...
- **URL:** https://www.facebook.com/groups/966324677961372/posts/1468654497728385/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS KENYA 0739557241
- **URL:** https://www.facebook.com/groups/1573778559875972/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### only 1550 u get your KOKO COOKER plus 2 free refills ...
- **URL:** https://www.facebook.com/groups/946341743435549/posts/1240761353993585/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103619903'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### only 1550 u get your KOKO COOKER plus 2 free refills ...
- **URL:** https://www.facebook.com/groups/946341743435549/posts/1240222714047449/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103619903'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED 0738002423
- **URL:** https://www.facebook.com/groups/886437143029196/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804', '0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mgas delivery services in Kenya with weekly payment plans
- **URL:** https://www.facebook.com/groups/598504922024144/posts/980260800515219/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0100863356'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...
- **URL:** https://www.facebook.com/groups/966324677961372/posts/1468502757743559/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### (SAFARICOM)MGAS KENYA 🇰🇪⛽ M-Gas Requirements
- **URL:** https://www.facebook.com/groups/408874720439060/posts/1237173760942481/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### HF Group Hiring In Nairobi 1. Scrum Master 2. Officer ...
- **URL:** https://www.facebook.com/groups/201801783357666/posts/2564973760373778/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

