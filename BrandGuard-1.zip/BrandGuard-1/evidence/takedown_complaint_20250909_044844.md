# Meta Takedown Request - M-Gas Kenya Brand Protection

**Generated:** 2025-09-09T04:48:44.674052  
**Complainant:** M-Gas Kenya Brand Protection Team  
**Grounds:** Trademark infringement, brand impersonation  

## Official Brand Reference
- **Page Name:** M-Gas
- **Entity Type:** Page 
- **Domain:** mgas.ke
- **Tagline:** "M-Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans."
- **Followers:** ~65,000

## Violating Entities (54 flagged)

### M-GAS Special offers - Facebook
- **URL:** https://www.facebook.com/events/526583930140239/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017', '0752611017', '0101447717'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Kenyan 254 market Buy and sell | Facebook
- **URL:** https://www.facebook.com/groups/913544077590514/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0762880299', '0762880299'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Facebook M-GAS COMPANY LTD 0787813153
- **URL:** https://www.facebook.com/groups/1416701029150257/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Facebook Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0111944487'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Your safety is... - M-Gas Franchising Philippines | Facebook
- **URL:** https://www.facebook.com/MGASFranchising/posts/your-safety-is-everything-a-friendly-reminder-to-only-buy-your-refills-from-auth/1014556045764181/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M GAS LIPA MOS MOS AGENT NUMBER CALL OR WHATSAPP ...
- **URL:** https://www.facebook.com/groups/1135545828247507/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103455159'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LTD AGENT CALL (0738002423/+ ...
- **URL:** https://www.facebook.com/groups/289318563672325/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['+254738286927'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers website...
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Albay Gas Corporation - Facebook Southern Gas Corporation Mindoro Branch | Calapan - Facebook MGAS NAGA MAIN - PALIT-TANGKE PROMO for only P930.00 ... M-Gas Franchising Philippines - GRAB THE CHANCE TO ... - Facebook Tierra Nevada Marketplace&Online Store | "One stop for all ... GRAB THE CHANCE TO WIN A... - M-Gas Franchising Philippines Brgy. Lambingan Tanza Cavite Palmerston North Ph1 ... - Facebook
- **URL:** https://www.facebook.com/100063718218905/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-gas Kenya limited special offers
- **URL:** https://www.facebook.com/groups/957825675925241/posts/mgas-with-special-offers-12-bob-tu-dial-479-ku-register-for-m-gas-leo-pikakwabei/1271854731188999/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED (0752611017)
- **URL:** https://www.facebook.com/groups/957825675925241/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mr. M's gas giveaway with cars lined up
- **URL:** https://www.facebook.com/groups/1115480395465731/posts/1757254114621686/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Original National ID ✅Safaricom Line ✅Deposit Of Ksh ...
- **URL:** https://www.facebook.com/groups/529071958129862/posts/1458314818538900/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Facebook M-GAS COMPANY LTD 0787813153
- **URL:** https://www.facebook.com/groups/1416701029150257/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Facebook Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0111944487'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Your safety is... - M-Gas Franchising Philippines | Facebook
- **URL:** https://www.facebook.com/MGASFranchising/posts/your-safety-is-everything-a-friendly-reminder-to-only-buy-your-refills-from-auth/1014556045764181/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook
- **URL:** https://www.facebook.com/61552820712644/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers website...
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook M-Gas - We're hiring in Kangemi! To apply, visit our careers ... M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... Samuel Namunga - We're hiring in Kakamega! To apply, visit... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED CALL (0784860605) | ANGUKIA OFFERS ZA # ...
- **URL:** https://www.facebook.com/groups/653145767783316/posts/709698335461392/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ANOTHER GIVEAWAY CHALLENGE! 🎉 Want ...
- **URL:** https://www.facebook.com/groups/844685979256352/posts/2667103730347892/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M GAS KENYA PIKA BILA STRESS CALL US or ...
- **URL:** https://www.facebook.com/groups/1006090580858866/posts/1414235310044389/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us at 0780683 ...
- **URL:** https://www.facebook.com/groups/1441100829930644/posts/1552119652162094/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0113986554'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us at 0780683 ...
- **URL:** https://www.facebook.com/groups/1441100829930644/posts/1552119652162094/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0113986554'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Gas Refilling ( *all types of gas cylinders)* 📌 Gas complete ...
- **URL:** https://www.facebook.com/groups/295474376849804/posts/706699862393918/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook
- **URL:** https://www.facebook.com/61552820712644/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### KENYAN ENTREPRENEURS IN DIASPORA | M GAS KENYA ... - Facebook
- **URL:** https://www.facebook.com/groups/1478775132392868/posts/3920559111547779/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0100136093'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### NAKURU BUYING AND SELLING LEGIT SECOND HAND ITEMS ... - Facebook
- **URL:** https://www.facebook.com/groups/758358989008652/posts/1330249241819621/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Tvs and accessories | Heavy duty and industrial use Italian ...
- **URL:** https://www.facebook.com/groups/243925403509550/posts/1458213798747365/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Huge moving sale. Make offers - Facebook
- **URL:** https://www.facebook.com/marketplace/item/1056932299939082/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### RAB MAKE OFFERS | Facebook
- **URL:** https://www.facebook.com/groups/2538049623048666/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas
- **URL:** https://www.facebook.com/story.php?story_fbid=605893695526164&id=100083166169294
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Ukiwa na M-Gas budget ya gas is totally up to you. ...
- **URL:** https://www.facebook.com/MGasKenya/photos/ukiwa-na-m-gas-budget-ya-gas-is-totally-up-to-you-imagine-uneza-pika-ugali-nyama/603558722426328/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook M-Gas - We're hiring! To apply, visit our careers ... - Facebook M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... M-Gas - We're hiring in Kangemi! To apply, visit our careers ... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Jikokoa and kuniokoa Kenya supply | #PROMO!..PROMO!!..PROMO
- **URL:** https://www.facebook.com/groups/1202896060426633/posts/1321237625259142/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0780346507'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | offer offers with only 550 ... - Facebook
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1025831539427440/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT> - Facebook Mgas kenya call 0750279398 - Facebook Genuine M-Gas Kenya L.T.D Helpline number 0101140606 | Facebook MGAS CUSTOMER SUPPORT - Facebook M-Gas Kenya | Facebook
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0755928849', '0750279398', '0750279398', '0101140606', '0736965095'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT> - Facebook
- **URL:** https://www.facebook.com/groups/907555054290862/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0755928849'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT - Facebook
- **URL:** https://www.facebook.com/groups/3644210639219066/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ELDORET TOWN DIRECTORY AND MARKETING AGENT | MGAS KENYA ...
- **URL:** https://www.facebook.com/groups/145297272312347/posts/2772549106253804/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0100594838'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### GITHUNGURI DAIRY FARMERS KENYA | Super ... - Facebook
- **URL:** https://www.facebook.com/groups/387081183783576/posts/558256573332702/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0100863356', '0753045802', '0753045802', '0753045802', '0753045802'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...
- **URL:** https://www.facebook.com/groups/966324677961372/posts/1468502757743559/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### (SAFARICOM)MGAS KENYA 🇰🇪⛽ M-Gas Requirements
- **URL:** https://www.facebook.com/groups/408874720439060/posts/1237173760942481/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers website...
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

