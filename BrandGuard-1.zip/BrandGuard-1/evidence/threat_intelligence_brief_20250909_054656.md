## Key Business Intelligence
- **Timeframe:** 2025-09-09 05:46:56 UTC
- **Scan Terms:** `M-Gas | M Gas | M-Gas Kenya | mgas ke | mgas kenya`
- **Findings Summary:** Total 87 suspects | Critical 69 | High 0 | Medium 0 | Low 0
- **Top 3 Risks (one line each):**
  1) End of June Promo‼️ For every 1 tank of 11kg M-gas, you will ... — Facebook Page — Critical — https://www.facebook.com/61573549531758/posts/end-of-june-promo️for-every-1-tank-of-11kg-m-gas-you-will-get-a-free-350ml-of-di/122135078354784984/
  2) M-GAS Special offers - Facebook — Facebook Page — Critical — https://www.facebook.com/events/526583930140239/
  3) Kenyan 254 market Buy and sell | Facebook — Facebook Group — Critical — https://www.facebook.com/groups/913544077590514/
- **Generated Files:**
  - Evidence CSV: evidence_workbook_20250909_054656.csv
  - Takedown Letter: takedown_complaint_20250909_054656.md
  - Intel Brief: threat_intelligence_brief_20250909_054656.md
- **Immediate Actions (max 3, imperative, with owner):**
  1) Submit takedown requests for 69 critical threats — **Owner:** Legal
  2) Brief customer service teams on 69 active threats — **Owner:** Fraud Ops

## Individual Threat Assessments

### End of June Promo‼️ For every 1 tank of 11kg M-gas, you will ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/61573549531758/posts/end-of-june-promo️for-every-1-tank-of-11kg-m-gas-you-will-get-a-free-350ml-of-di/122135078354784984/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS Special offers - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/events/526583930140239/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Kenyan 254 market Buy and sell | Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/913544077590514/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Mr. M's gas giveaway with cars lined up  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1115480395465731/posts/1757254114621686/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Willie Wilson's $1M gas giveaway starts in a few hours. Sarah ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/WGNMorningNews/videos/willie-wilsons-1m-gas-giveaway-starts-in-a-few-hours-sarah-jindra-has-the-latest/307075588218789/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Facebook M Gas Kenya - Facebook M-gas Company Kenya - Facebook M-GAS COMPANY LTD 0787813153 | Facebook M-Gas Kenya> - Facebook M-GAS KENYA LIMITED (0111944487) | Need assistance with your .....  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-gas now, Pay Later! Get 3 LPG refills for only 50 pesos per day ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://m.facebook.com/mgasconcepciontarlac/posts/m-gas-now-pay-laterget-3-lpg-refills-for-only-50-pesos-per-daycontact-us-0998583/122120095448783567/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Mascom Gas Trading Gas Refilling and Exchanges ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1651677148403782/posts/3990681181170022/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M GAS LIPA MOS MOS AGENT NUMBER CALL OR WHATSAPP ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1135545828247507/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### FURAHIA UPISHI ENJOY COOKING WITH M-GAS AGENT ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/359545889779700/posts/765024569231828/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We are Hiring M-Gas is seeking motivated and dynamic ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### End of June Promo‼️ For every 1 tank of 11kg M-gas, you will ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/61573549531758/posts/end-of-june-promo️for-every-1-tank-of-11kg-m-gas-you-will-get-a-free-350ml-of-di/122135078354784984/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-gas Kenya limited special offers  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/mgas-with-special-offers-12-bob-tu-dial-479-ku-register-for-m-gas-leo-pikakwabei/1271854731188999/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### m-gas kenya limited (0752611017) | angukia offers za ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1310628327311639/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Mr. M's gas giveaway with cars lined up  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1115480395465731/posts/1757254114621686/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Willie Wilson's $1M gas giveaway starts in a few hours. Sarah ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/WGNMorningNews/videos/willie-wilsons-1m-gas-giveaway-starts-in-a-few-hours-sarah-jindra-has-the-latest/307075588218789/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Facebook M-gas Company Kenya - Facebook M Gas Kenya - Facebook M-GAS COMPANY LTD 0787813153 | Facebook M-GAS COMPANY 0787813153 - Facebook M-GAS KENYA LIMITED (0111944487) | Need assistance with your .....  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Albay Gas Corporation - Facebook MGAS - Welcome to the Official Page of M-GAS TAYTAY! We ... M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook MGAS CUSTOMER SUPPORT - Facebook We are built and ready to support... - Alacrity Solutions  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/100063718218905/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • false authority claims • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Your safety is... - M-Gas Franchising Philippines | Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGASFranchising/posts/your-safety-is-everything-a-friendly-reminder-to-only-buy-your-refills-from-auth/1014556045764181/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/61552820712644/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We are Hiring M-Gas is seeking motivated and dynamic ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### charcoal stove promo is  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/307365138803135/posts/charcoal-stove-promo-is-still-going-onprice-is-large-3100medium-2600small-1850no/708675682005410/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M GAS KENYA PIKA BILA STRESS 2️⃣ Burners=@550 ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/878566720242965/posts/1506157904150507/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • promo + giveaways
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS KENYA LIMITED (0752611017)  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M Gas Kenya offers gas delivery services  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1140874097101535/posts/1484917839363824/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### ANOTHER GIVEAWAY CHALLENGE! 🎉 Want ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/844685979256352/posts/2667103730347892/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M GAS KENYA PIKA BILA STRESS CALL US or ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1006090580858866/posts/1414235310044389/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M Gas Kenya - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/61573685076479/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us at 0780683 ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1441100829930644/posts/1552119652162094/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Gas Refilling ( *all types of gas cylinders)* 📌 Gas complete ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/295474376849804/posts/706699862393918/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/61552820712644/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### KENYAN ENTREPRENEURS IN DIASPORA | M GAS KENYA ... - Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1478775132392868/posts/3920559111547779/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M GAS KENYA PIKA BILA STRESS 2️⃣ Burners=@550 ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1735312360030079/posts/4410570792504209/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M GAS KENYA PIKA KILA WAKATI...CALL US 0100-337-463 OR ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1848134362617928/posts/1853188662112498/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We are Hiring M-Gas is seeking motivated and dynamic ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/359545889779700/posts/673762361691383/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We're hiring in Kitale! To apply, visit our careers website or ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1066779485029859/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Modern COAST ltd  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/people/Modern-COAST-ltd/100092931717354/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Book your ticket know according to you ability. .NBVip class ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://m.facebook.com/100092931717354/posts/book-your-ticket-know-according-to-you-abilitynbvip-class-fares-will-vary-accord/106227452468613/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Huge moving sale. Make offers - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/marketplace/item/1056932299939082/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Must Sell - Make Offers - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/commerce/listing/1305861917875215/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Other posts - Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/893208048514351/posts/1252343285934157/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Mgas Upishi Smart Ke - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/people/Mgas-Upishi-Smart-Ke/61559184901854/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Facebook M-Gas - Tumefika Kitengela! You can now get to enjoy... Mgas Upishi Smart - Facebook M-Gas - Pika smart na M-Gas clean, safe, na perfect kwa ... M-gas Kenyan - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### FurahiaUpishiWako #cleancooking #affordablecooking #MGAS  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://m.facebook.com/MGasKenya/photos/furahiaupishiwako-cleancooking-affordablecooking-mgas/605610748887792/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Ukiwa na M-Gas budget ya gas is totally up to you. ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/photos/ukiwa-na-m-gas-budget-ya-gas-is-totally-up-to-you-imagine-uneza-pika-ugali-nyama/603558722426328/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Beware of Fraudsters purporting to work for M-Gas! We will ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/posts/beware-of-fraudsters-purporting-to-work-for-m-gas-we-will-never-ask-you-for-any-/504629532319248/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://m.facebook.com/story.php?story_fbid=621403657308501&id=100083166169294
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Facebook M-Gas - We're hiring! To apply, visit our careers ... - Facebook M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... M-Gas - We're hiring in Kangemi! To apply, visit our careers ... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Jikokoa and kuniokoa Kenya supply | #PROMO!..PROMO!!..PROMO  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1202896060426633/posts/1321237625259142/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### 0782946741 Mgas kenya imekuja na offer kibao  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/2502306723286057/posts/2900756940107698/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • promo + giveaways
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS OFFERS YOU BEST SERVICES EVER!! DEPOSIT ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/653145767783316/posts/740289502402275/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS KENYA LIMITED SERVICE 0780163350 | Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1098251691916760/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Mgas Kenya are you interested What is the best  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/abujacarbusiness/posts/2169648750202515/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### ALMOST GIVEAWAY! 🏃🏃💨 💜💚 GET A QUALITY FOAM POA ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/776036066350650/posts/1764225280865052/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/907555054290862/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS KENYA CALL 📞 OR WHATSAPP 0736965095 Low ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1327884598298290/posts/mgas-kenya-call-or-whatsapp-0736965095low-upfront-cost-low-initial-stove-deposit/1341723926914357/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/966324677961372/posts/1468654497728385/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS KENYA 0739557241  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1573778559875972/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### only 1550 u get your KOKO COOKER plus 2 free refills ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/946341743435549/posts/1240761353993585/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### only 1550 u get your KOKO COOKER plus 2 free refills ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/946341743435549/posts/1240222714047449/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### ELDORET TOWN DIRECTORY AND MARKETING AGENT | MGAS KENYA ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/145297272312347/posts/2772549106253804/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### GITHUNGURI DAIRY FARMERS KENYA | Super ... - Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/387081183783576/posts/558256573332702/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### (SAFARICOM)MGAS KENYA 🇰🇪⛽ M-Gas Requirements  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/408874720439060/posts/1237173760942481/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Mgas Kenya are you interestedWhat is the best type you want ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/359545889779700/posts/mgas-kenya-are-you-interestedwhat-is-the-best-type-you-want-the-most-2-burners-5/694431352957817/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### HF Group Hiring In Nairobi 1. Scrum Master 2. Officer ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/201801783357666/posts/2564973760373778/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas Concepcion Tarlac  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/mgasconcepciontarlac/posts/avail-our-101-promo️buy-10-11-kg-m-gas-refill-and-get-1-free-for-only-php-9400ex/122113851290783567/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Need assistance with your M-Gas? Call us at 0800...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/571958275586373/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us at 0800 721 ...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/need-assistance-with-your-m-gas-call-us-at-0800-721-148-our-dedicated-customer-c/571958275586373/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MAKATI JOB HIRING | Facebook  —  **Facebook Group**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/groups/743819387078940/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We are Hiring M-Gas is seeking motivated and dynamic ...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiring-m-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regi/688151853967014/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas Concepcion Tarlac  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/mgasconcepciontarlac/posts/avail-our-101-promo️buy-10-11-kg-m-gas-refill-and-get-1-free-for-only-php-9400ex/122113851290783567/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Need assistance with your M-Gas? Call us at 0800...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/571958275586373/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Southern Gas Corporation Mindoro Branch | Calapan - Facebook Albay Gas Corporation - Facebook MGAS - Welcome to the Official Page of M-GAS TAYTAY! We ... M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook MGAS CUSTOMER SUPPORT - Facebook We are built and ready to support... - Alacrity Solutions  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/OrMinIslandGas/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • false authority claims • missing official tagline
- **Confidence:** High
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-gas Masagana, Argas, Prycegas and Superkalan Shine LPG Tank Your safety is... - M-Gas Franchising Philippines | Facebook We offer gas bottle refills & exchange... - Mica Durban North ... Fast AC/Refrigerator repairs&gas refills - Facebook Need gas? At Builders, we offer gas refill and exchange ... Does anyone refill gas bottles in town - Facebook Hip2Save - 64 ounces, $19.99 + $1.79 refills at my gas...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/ArgasPrycegasMgasShinegasDealer/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### SAFARICOM M-GAS AGENT - Facebook  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/safaricommgasagent/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MAKATI JOB HIRING | Facebook  —  **Facebook Group**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/groups/743819387078940/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We are Hiring M-Gas is seeking motivated and dynamic ...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiring-m-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regi/688151853967014/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Need assistance with your M-Gas? Call us at 0800...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/571958275586373/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### ATHIRIVER KITENGELA ONLINE MARKET | Airbnb Kitengela - Facebook  —  **Facebook Group**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/groups/Athiriver/posts/24569357419366624/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • false authority claims • missing official tagline
- **Confidence:** High
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us at 0800 721 ...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/need-assistance-with-your-m-gas-call-us-at-0800-721-148-our-dedicated-customer-c/571958275586373/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We are Hiring! M-Gas is seeking motivated and dynamic ...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-to-join-our-team/591689360279931/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiring-in-nairobim-gas-is-seeking-motivated-and-dynamic-individuals-in-na/586877434094457/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Join Careers Crafters Network for more job vacancies, don`...  —  **Facebook Group**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/groups/1548824975418165/posts/3632644573702851/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.