# Individual Threat Assessment Report
**Generated:** 2025-09-09 05:57:56 UTC  
**Analyst:** BrandGuard Enterprise OSINT System  
**Brand:** M-Gas Kenya

## Assessment Overview
This report provides detailed analysis of each detected threat against M-Gas Kenya's digital presence, with prioritized risk assessments and actionable recommendations for enforcement teams.

**Total Entities Analyzed:** 72  
**Assessment Methodology:** Automated OSINT + Professional Risk Scoring  
**Compliance:** Meta ToS compliant public data analysis  

## Individual Threat Profiles

### 🚨 Threat Profile #1: M-Gas Franchising Philippines - GRAB THE CHANCE TO ... - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGASFranchising/photos/a.142069996346128/473635186522939/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** false authority claims • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Congrats mgas M - Gas Franchising Philippines Jul 6 📣 Franchise Pinas Day 2 is Officially ON! Happening TODAY, July 6 from 10AM to 9PM at SMX Clark — ...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #2: M-gas Kenya limited special offers

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/957825675925241/posts/mgas-with-special-offers-12-bob-tu-dial-479-ku-register-for-m-gas-leo-pikakwabei/1271854731188999/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** MGAS With Special offers 12 bob tu! Dial *479# ku register for M-Gas leo. #PikaKwaBeiYako #FurahiaUpishiWako #MGas Call 0752611017 Deposit ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #3: M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/966324677961372/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S APP 0755471873 is a ... @everyone Amazing offers just for you, Sasa 550 Pekee imetosha , Kupika Ni ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #4: SKYWAVE ADVERTS> - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1209168100409027/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M Gas Compa Feb 19 Free files on Whatsapphttps://chat.whatsapp. com/I4rQpfU7znv7KN64UwKlzq Cesar Benitez Arce and 3 others 4 4 Vpn File Feb 19 https:/...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #5: M-Gas - Facebook M Gas Kenya - Facebook M-gas Company Kenya - Facebook M-GAS COMPANY LTD 0787813153 | Facebook M-Gas Kenya> - Facebook M-GAS KENYA LIMITED (0111944487) | Need assistance with your .....

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M - Gas . 54,749 likes · 271 talking about this. M - Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans. M Gas Kenya May 13 T...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #6: Need assistance with your M-Gas? Call us

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Need assistance with your M-Gas ? Call us at 0111944487,or Any inquiry of our services. our dedicated customer care team is ready to support ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #7: Your safety is... - M-Gas Franchising Philippines | Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGASFranchising/posts/your-safety-is-everything-a-friendly-reminder-to-only-buy-your-refills-from-auth/1014556045764181/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jan 31, 2022 · Your safety is EVERYTHING. 💯 A friendly reminder to only buy your refills from authorized distributors to ensure your tanks are new, we...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #8: M GAS LIPA MOS MOS AGENT NUMBER CALL OR WHATSAPP ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1135545828247507/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M GAS LIPA MOS MOS AGENT NUMBER CALL OR WHATSAPP US ON 01034551594 > · Ukiwa na deposit ya 550/= Unapokea m-gas yako leo kila wiki utakua unalipia 35/...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #9: M-GAS KENYA LTD AGENT CALL (0738002423/+ ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/289318563672325/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** We Are Offering M-Gas (+254738286927). At A Minimum Deposit Of 550/= You Get A 13kgs Cylinder And Two Burners Gas Cooker. @highlight M-GAS KENYA LTD A...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #10: Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** 1 day ago · Let's get some gas for Kanicy Kamwaosh to make some porridge for her child. Ongwae Kerubo Dee please refill her M-gas account . #TeamOrwa...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #11: We are Hiring M-Gas is seeking motivated and dynamic ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Hello Serge Pk Ibaaka, regularly check our website page at: https://mgas.ke/ under the Careers tab for the latest job openings! mgas.ke. M-Gas | ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #12: End of June Promo‼️ For every 1 tank of 11kg M-gas, you will ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/61573549531758/posts/end-of-june-promo️for-every-1-tank-of-11kg-m-gas-you-will-get-a-free-350ml-of-di/122135078354784984/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** End of June Promo ‼️ For every 1 tank of 11kg M-gas , you will get a free 350ml of Dishwashing Liquid. Promo runs until supplies last. Contact# (0998)...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #13: ENJOY COOKING WITH M~GAS💥 ✅️Deposit 550 shillings ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/878566720242965/posts/1526146258818338/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ... M-GAS M -GAS AFFORDABLE LPG You decide how much to spend. miGas ... SUN KING OFFICE LINE * 09164224523 PROMO ! PROMO !! PROMO ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #14: M-GAS Special offers - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/events/526583930140239/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Details Enjoy Quality Cooking Services From M - Gas :0752611017 at a minimum deposit Of 550/= Weekly Charges Of 35/= for 9mths Click On The Logo To Vi...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #15: Kenyan 254 market Buy and sell | Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/913544077590514/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Clinton Okumu Jan 3 💥FESTIVE SEASON OFFERS 💥 M - GAS KENYA PIKA BILA STRESS ..⭐CALL US 0762880299 ⭐WHATSAPP🔥0762880299 SAFARICOM M GAS IS A SAFARICOM ...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #16: Look who’s happy! Our M-GAS 1st Anniver-saya Giveaway GRAND ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/mgaswincytrading/videos/look-whos-happy-our-m-gas-1st-anniver-saya-giveaway-grand-prize-winner-just-clai/329821892213407/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** name spoof variant • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ‘Til our next pa giveaway ! For queries and deliveries, contact us at (Smart) 0949 148 3732 (Globe) 0927 495 5245 Or visit us at Mgas Wincy Trading, S...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #17: M-Gas - Facebook M-gas Company Kenya - Facebook M Gas Kenya - Facebook M-GAS COMPANY LTD 0787813153 | Facebook M-GAS COMPANY 0787813153 - Facebook M-GAS KENYA LIMITED (0111944487) | Need assistance with your .....

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M - Gas . 54,749 likes · 271 talking about this. M - Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans. ilikupokea huduma za...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #18: Albay Gas Corporation - Facebook MGAS - Welcome to the Official Page of M-GAS TAYTAY! We ... M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook MGAS CUSTOMER SUPPORT - Facebook We are built and ready to support... - Alacrity Solutions

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/100063718218905/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** false authority claims • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jun 10, 2021 · M-Gas Franchising Philippines Mar 22, 2021 Ms. Irma Gonzales has been an authorized reseller of Island Gas for years and last year, she...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #19: Your safety is... - M-Gas Franchising Philippines | Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGASFranchising/posts/your-safety-is-everything-a-friendly-reminder-to-only-buy-your-refills-from-auth/1014556045764181/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jan 31, 2022 · Your safety is EVERYTHING. 💯 A friendly reminder to only buy your refills from authorized distributors to ensure your tanks are new, we...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #20: M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/61552820712644/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M - GAS Kenya LTD Agent Call 0103676804, Westlands. 14 likes · 161 talking about this. Home Businesses...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #21: Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** 1 day ago · Let's get some gas for Kanicy Kamwaosh to make some porridge for her child. Ongwae Kerubo Dee please refill her M-gas account . #TeamOrwa...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #22: M-Gas - We're hiring! To apply, visit our careers website...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jul 10, 2023 · We're hiring! To apply, visit our careers website or click on the link https:// careers . mgas .ke/ #FurahiaUpishiWako #cleancooking #a...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #23: M-Gas - Facebook M-Gas - We're hiring in Kangemi! To apply, visit our careers ... M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... Samuel Namunga - We're hiring in Kakamega! To apply, visit... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M - Gas . 54,749 likes · 271 talking about this. M - Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans. Jul 17, 2023 · We're...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #24: M-GAS KENYA LIMITED CALL (0784860605) | ANGUKIA OFFERS ZA # ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/653145767783316/posts/709698335461392/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ANGUKIA OFFERS ZA # MGAS . DEPOSIT, (1) burners 550 shillings (2) Weekly Installment 35Bob. CALL US TODAY......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #25: MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** @highlight offer offers with only 550 tunakuletea MGAS mpaka nyumbani, call or WhatsApp us on 0106948302 utakua ukilipia 25 per day order today and......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #26: ANOTHER GIVEAWAY CHALLENGE! 🎉 Want ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/844685979256352/posts/2667103730347892/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ANOTHER GIVEAWAY CHALLENGE! Want to WIN a ... ANOTHER GIVEAWAY CHALLENGE! Want to WIN ... M-GAS KENYA LIMITED COMPANY, Mercy Abungu, Jonathan G....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #27: M GAS KENYA PIKA BILA STRESS CALL US or ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1006090580858866/posts/1414235310044389/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M GAS KENYA PIKA BILA STRESS CALL US or WHATSAPP + ... Ellen DeGeneres giveaway profile picture. Ellen DeGeneres giveaway . 5d ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #28: Need assistance with your M-Gas? Call us

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ... customer care team is ready to support you every step of the way ... M-GAS KENYA LIMITED (0752611017) | Need assistance with your M ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #29: Need assistance with your M-Gas? Call us at 0780683 ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1441100829930644/posts/1552119652162094/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ... customer care team is ready to support you every ... M-GAS KENYA LIMITED (0113986554) | Need ... our dedicated customer care team is ready to supp...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #30: MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/3644210639219066/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT > Public group · 28 members Join group About this group If you are unable to locate my message, kindly use ...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #31: M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/61552820712644/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M - GAS Kenya LTD Agent Call 0103676804, Westlands. 14 likes · 161 talking about this. Home Businesses...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #32: KENYAN ENTREPRENEURS IN DIASPORA | M GAS KENYA ... - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1478775132392868/posts/3920559111547779/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M GAS KENYA PIKA KILA WAKATI...CALL. AGENT JIMMY CLIFF☎️..0100136093 SAFARICOM M GAS IS A SAFARICOM SPONSORED GAS ️ M GAS DEPOSIT 550 KSH COMES WITH.....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #33: NAKURU BUYING AND SELLING LEGIT SECOND HAND ITEMS ... - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/758358989008652/posts/1330249241819621/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** 1 hr Kuhana Atia Hii sio hiyo kabarabara kanatokea main ya naiswet 1 hr 1 Kibet Terer Torkotin Lakini hata watu wanaharibu barabara now days, unapata ...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #34: Tvs and accessories | Heavy duty and industrial use Italian ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/243925403509550/posts/1458213798747365/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M - GAS KENYA LIMITED 0784 920818 ️𝐃𝐞𝐩𝐨𝐬𝐢𝐲 𝐊𝐬𝐡.550/= ️𝐖𝐞𝐞𝐤𝐥𝐲 𝐊𝐬𝐡.35/= ️𝐓𝐰𝐨 𝐖𝐞𝐞𝐤𝐬 𝐅𝐫𝐞𝐞 𝐔𝐬𝐚𝐠𝐞 ️𝐅𝐫𝐞𝐞 𝐓-𝐒𝐡𝐢𝐫𝐭,𝐔𝐦𝐛𝐫𝐞𝐥𝐥𝐚, & 𝐋𝐢𝐪𝐮𝐢𝐝 𝐒𝐨𝐚𝐩...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #35: M-Gas - We're hiring! To apply, visit our careers ... - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jul 10, 2023 · We're hiring! To apply, visit our careers website or click on the link https:// careers .mgas.ke/ #FurahiaUpishiWako #cleancooking #aff...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #36: Modern COAST ltd

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/people/Modern-COAST-ltd/100092931717354/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Let them use promo code D7948150 when booking. NAIROBI ➡KIGALI daily ... Mgas Ke and 2 others · . 3 · · Modern COAST ltd profile picture. Modern COAST...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #37: Book your ticket know according to you ability. .NBVip class ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://m.facebook.com/100092931717354/posts/book-your-ticket-know-according-to-you-abilitynbvip-class-fares-will-vary-accord/106227452468613/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Let them use promo code D7948150 when booking. NAIROBI ➡KIGALI ... Mgas Ke and 2 others · . 3 · . Related Pages. Mogo loan motorcycle ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #38: Huge moving sale. Make offers - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/marketplace/item/1056932299939082/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Please dm for prices and or make offer - all must go! Thanks for looking shoes are new size 11 women - $40 Wall art make offers Round wood Table $60 A...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #39: Must Sell - Make Offers - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/commerce/listing/1305861917875215/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** $1 per item · In Stock Listed on Friday in Garden City, MO Description Make offers Must pick up in Garden City MO this weekend CASH ONLY More items in...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #40: Mgas Upishi Smart Ke - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/people/Mgas-Upishi-Smart-Ke/61559184901854/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Nov 22, 2024 · to serve you. For any customer service needs, call us on our toll- free Customer Care number at 0105 004775 chat with us on WhatsApp at...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #41: M-Gas - Facebook M-Gas - Tumefika Kitengela! You can now get to enjoy... Mgas Upishi Smart - Facebook M-Gas - Pika smart na M-Gas clean, safe, na perfect kwa ... M-gas Kenyan - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** mgas .ke M - Gas Aug 15 Are you passionate about creating sustainable impact and driving results ? We’re looking for enthusiastic personnel to join ou...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #42: M-Gas - Facebook M-Gas - We're hiring! To apply, visit our careers ... - Facebook M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... M-Gas - We're hiring in Kangemi! To apply, visit our careers ... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** mgas .ke M- Gas Aug 15 Are you passionate about creating sustainable impact and driving results ? We’re looking for enthusiastic personnel to join our...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #43: M-Gas - We're hiring! To apply, visit our careers ... - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jul 10, 2023 · We're hiring! To apply, visit our careers website or click on the link https:// careers . mgas . ke / #FurahiaUpishiWako #cleancooking ...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #44: Jikokoa and kuniokoa Kenya supply | #PROMO!..PROMO!!..PROMO

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1202896060426633/posts/1321237625259142/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jan 8, 2024 · Josline Esendi 6d Ni ya leo 🤌Mgas kenya imekuja na offer kibao Ukiwa na deposit ya 550 pekee tunakupea gas pamoja na 13kg clynder uwe uk...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #45: MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** @highlight Ni ya leo 🤌Mgas kenya imekuja na offer kibao Ukiwa na deposit ya 550 pekee tunakupea gas pamoja na 13kg clynder uwe ukijilipia 25per day fo...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #46: MGAS MKOPO 0106948302 | offer offers with only 550 ... - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1025831539427440/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** offer offers with only 550 tunakuletea MGAS mpaka nyumbani, call or WhatsApp us on 0106948302 utakua ukilipia 25 per day order today and enjoy free. 1...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #47: M-Gas - Facebook MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT> - Facebook Mgas kenya call 0750279398 - Facebook Genuine M-Gas Kenya L.T.D Helpline number 0101140606 | Facebook MGAS CUSTOMER SUPPORT - Facebook M-Gas Kenya | Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M-Gas. 54,749 likes · 271 talking about this. M-Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans. Nov 30, 2024 · Furahia Up...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #48: MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT> - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/907555054290862/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Nov 30, 2024 · Furahia Upishi poa na Mgas Kenya . Call/whatsapp 0755928849. We offer free delivery country wide....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #49: MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/3644210639219066/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT > Public group · 28 members Join group About this group If you are unable to locate my message, kindly use ...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #50: ELDORET TOWN DIRECTORY AND MARKETING AGENT | MGAS KENYA ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/145297272312347/posts/2772549106253804/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** MGAS KENYA SPECIAL OFFERS KWA KILA MTU? DEPOSIT IS NOW KSH.350/= DAILY PAYMENT KSH.20 BOB /= CALL US 0100594838...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #51: GITHUNGURI DAIRY FARMERS KENYA | Super ... - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/387081183783576/posts/558256573332702/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Join MGAS KENYA : 0100863356 2.3K members Join Copia offers 14K members Join CITIZEN DUKA 1.8K members Join Delamere FARM Naivasha 0753045802 GITHUNGU...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #52: M-Gas - We're hiring! To apply, visit our careers website...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jul 10, 2023 · We're hiring! To apply, visit our careers website or click on the link https:// careers . mgas .ke/ #FurahiaUpishiWako #cleancooking #a...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 🚨 Threat Profile #53: M-Gas - We're hiring! To apply, visit our careers ... - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jul 10, 2023 · We're hiring! To apply, visit our careers website or click on the link https:// careers . mgas .ke/ #FurahiaUpishiWako #cleancooking #a...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #54: Southern Gas Corporation Mindoro Branch | Calapan - Facebook M-Gas Franchising Philippines - GRAB THE CHANCE TO ... - Facebook GRAB THE CHANCE TO WIN A... - M-Gas Franchising Philippines Bob Almeda - Facebook Day 1 Island Gas and M-Gas... - Island Gas - Bicol Region ... Tierra Nevada Marketplace&Online Store | "One stop for all ... RJN Enterprises | Makati - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/OrMinIslandGas/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Thank you for the trust and support, mr. Ritchard! We are here to support you throughout your M - GAS Journey. We are still open here in Calapan Orien...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #55: Import and Export in Korea> - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/982277263105399/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** [4/20, 11:03 AM] Nelson Kelechi: 🎗️🔥🔥3 *in1 🛢️ OIL 🪔 AND GAS ⛽ LICENSES FOR SALE AT A GIVEAWAY PRICE* 🔥🔥 Our Seller is offering 3 separate licenses fo...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #56: M-Gas - Need assistance with your M-Gas? Call us at 0800...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/571958275586373/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Need assistance with your M - Gas ? Call us at 0800 721 148, our dedicated customer care team is ready to support you every step of the way!......
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #57: Need assistance with your M-Gas? Call us at 0800 721 ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/need-assistance-with-your-m-gas-call-us-at-0800-721-148-our-dedicated-customer-c/571958275586373/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Need assistance with your M-Gas ? Call us at 0800 721 148, our dedicated customer care team is ready to support you every step of the way!...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #58: M-gas Masagana, Argas, Prycegas and Superkalan Shine LPG Tank Your safety is... - M-Gas Franchising Philippines | Facebook ATHIRIVER KITENGELA ONLINE MARKET | Airbnb Kitengela - Facebook Samuel Grenier, page publique | See I'm at the gas station ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/ArgasPrycegasMgasShinegasDealer/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** M - gas Masagana, Argas , Prycegas and Superkalan Shine LPG Tank. 1,802 likes · 1 talking about this. We deliver along NAIC CAVITE LPG SGAS ARGAS PRYC...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #59: MAKATI JOB HIRING | Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/743819387078940/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** ☑️ Preferably with HR experience, but fresh graduates are welcome to apply ☑️ Proficient in MS Office Applications ☑️ Has excellent oral and written c...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #60: We are Hiring M-Gas is seeking motivated and dynamic ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiring-m-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regi/688151853967014/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** ... ://mgas.ke/ careers / or Job Links: https://mgas. seamlesshiring.com/h/advanced#/jobs and apply. mgas.ke. Careers | M-Gas . 3 mos. Evans Opiyo....
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #61: Just got lucky! Our Merry Christ-Manalo Giveaway 1st Prize ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/mgaswincytrading/videos/just-got-lucky-our-merry-christ-manalo-giveaway-1st-prize-category-1-winner-uses/621714182418819/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Jan 25, 2022 · Our Merry Christ-Manalo Giveaway 1st Prize Category 1 winner uses his M - Gas 2.7kgs for his siomai business. Para sa marami pang sioma...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #62: M-Gas - Need assistance with your M-Gas? Call us at 0800...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/571958275586373/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Need assistance with your M - Gas ? Call us at 0800 721 148, our dedicated customer care team is ready to support you every step of the way!......
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #63: Southern Gas Corporation Mindoro Branch | Calapan - Facebook Albay Gas Corporation - Facebook MGAS - Welcome to the Official Page of M-GAS TAYTAY! We ... M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook MGAS CUSTOMER SUPPORT - Facebook We are built and ready to support... - Alacrity Solutions

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/OrMinIslandGas/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** false authority claims • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Thank you for the trust and support , mr. Ritchard! We are here to support you throughout your M-GAS Journey. We are still open here in Calapan Orient...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #64: M-gas Masagana, Argas, Prycegas and Superkalan Shine LPG Tank Your safety is... - M-Gas Franchising Philippines | Facebook We offer gas bottle refills & exchange... - Mica Durban North ... Fast AC/Refrigerator repairs&gas refills - Facebook Need gas? At Builders, we offer gas refill and exchange ... Does anyone refill gas bottles in town - Facebook Hip2Save - 64 ounces, $19.99 + $1.79 refills at my gas...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/ArgasPrycegasMgasShinegasDealer/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** M - gas Masagana, Argas, Prycegas and Superkalan Shine LPG Tank. 1,802 likes · 1 talking about this. We deliver along NAIC CAVITE LPG SGAS ARGAS PRYCE...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #65: SAFARICOM M-GAS AGENT - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/safaricommgasagent/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** SAFARICOM M - GAS AGENT is on Facebook. Join Facebook to connect with SAFARICOM M - GAS AGENT and others you may know. Facebook gives people the power...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #66: MAKATI JOB HIRING | Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/743819387078940/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** ☑️ Preferably with HR experience, but fresh graduates are welcome to apply ☑️ Proficient in MS Office Applications ☑️ Has excellent oral and written c...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #67: MGAS CUSTOMER SUPPORT - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/mgas.kenya.care/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** MGAS CUSTOMER SUPPORT is on Facebook. Join Facebook to connect with MGAS CUSTOMER SUPPORT and others you may know. Facebook gives people the power to....
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #68: ATHIRIVER KITENGELA ONLINE MARKET | Airbnb Kitengela - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/Athiriver/posts/24569357419366624/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** false authority claims • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Aug 31, 2025 · - Pressure pump refills the top tank automatically. - Reliable water supply available 24/7. - Common perimeter electric fence. - Securi...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #69: M-Gas - Facebook M-Gas - We're hiring! To apply, visit our careers ... - Facebook M-Gas - We're hiring in Kangemi! To apply, visit our careers ... Sharon Gas Profiles - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** ke/ careers /Job Links: https://mgas.seamlesshiring. com/h/advanced#/jobs Nickens Nickens and 150 others 151 94 M- Gas Jul 10 Pika smart na M - Gas cl...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #70: Alga cloth | Tanda - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/61566467623470/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Nov 13, 2024 · cleaning agent , has been used in households and industries for years. However, its applications go far beyond the confines of home cle...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #71: Skyland Net Management | Semarang - Facebook Launcher - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/skylandteam/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Aug 1, 2024 · Skyland Net Management, Semarang. 4,723 likes · 1 talking about this · 228 were here. Semarang Jl. Durian Raya 73.Banyumanik Jl. Arteri ...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---

### 📝 Threat Profile #72: MGAS CUSTOMER SUPPORT - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/mgas.kenya.care/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** MGAS CUSTOMER SUPPORT is on Facebook. Join Facebook to connect with MGAS CUSTOMER SUPPORT and others you may know. Facebook gives people the power to....
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:57:56 UTC

---


## Summary & Next Steps

**Assessment Complete:** 2025-09-09 05:57:56 UTC
**Total Analyzed:** 72 entities
**Enforcement Ready:** 53 high-priority cases

**Recommended Actions:**
1. **Legal Team:** Review P1/P2 priority cases for takedown requests
2. **Communications:** Prepare customer advisories if fraud indicators present  
3. **Monitoring:** Continue surveillance for new impersonation attempts

**Report Distribution:**
- Legal Counsel (for enforcement decisions)
- Brand Protection Team (for strategic planning)  
- Customer Support (for fraud awareness)

---
*This report contains confidential business intelligence. Distribution restricted to authorized personnel.*
