# Meta Takedown Request - M-Gas Kenya Brand Protection

**Generated:** 2025-09-09T05:15:04.869209  
**Complainant:** M-Gas Kenya Brand Protection Team  
**Grounds:** Trademark infringement, brand impersonation  

## Official Brand Reference
- **Page Name:** M-Gas
- **Entity Type:** Page 
- **Domain:** mgas.ke
- **Tagline:** "M-Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans."
- **Followers:** ~65,000

## Violating Entities (53 flagged)

### Albay Gas Corporation - Facebook
- **URL:** https://www.facebook.com/100063718218905/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Special offers - Facebook
- **URL:** https://www.facebook.com/events/526583930140239/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017', '0752611017', '0101447717'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Kenyan 254 market Buy and sell | Facebook
- **URL:** https://www.facebook.com/groups/913544077590514/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0762880299', '0762880299'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mr. M's gas giveaway with cars lined up
- **URL:** https://www.facebook.com/groups/1115480395465731/posts/1757254114621686/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Original National ID ✅Safaricom Line ✅Deposit Of Ksh ...
- **URL:** https://www.facebook.com/groups/529071958129862/posts/1458314818538900/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Albay Gas Corporation - Facebook M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook GAS STATION BUSINESS PHILIPPINES | Facebook MADAM ANA M-GAS | Facebook Dominico LPG Trading | Binangonan - Facebook
- **URL:** https://www.facebook.com/100063718218905/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-gas now, Pay Later! Get 3 LPG refills for only 50 pesos per day ...
- **URL:** https://m.facebook.com/mgasconcepciontarlac/posts/m-gas-now-pay-laterget-3-lpg-refills-for-only-50-pesos-per-daycontact-us-0998583/122120095448783567/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0998583939'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Safaricom and M-Gas launched the revolutionary, prepaid ...
- **URL:** https://www.facebook.com/groups/954366519042739/posts/1170291037450285/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['+254107453715'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook
- **URL:** https://www.facebook.com/61552820712644/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers website...
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Albay Gas Corporation - Facebook
- **URL:** https://www.facebook.com/100063718218905/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Special offers - Facebook
- **URL:** https://www.facebook.com/events/526583930140239/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Kenyan 254 market Buy and sell | Facebook
- **URL:** https://www.facebook.com/groups/913544077590514/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0762880299', '0762880299'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### SKYWAVE ADVERTS> - Facebook
- **URL:** https://www.facebook.com/groups/1209168100409027/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook M-gas Company Kenya - Facebook M Gas Kenya - Facebook M-GAS COMPANY LTD 0787813153 | Facebook M-GAS COMPANY 0787813153 - Facebook M-GAS KENYA LIMITED (0111944487) | Need assistance with your .....
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106926827', '0104778819', '0746447820', '0737559526', '0787813153', '0111944487'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0111944487'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Your safety is... - M-Gas Franchising Philippines | Facebook
- **URL:** https://www.facebook.com/MGASFranchising/posts/your-safety-is-everything-a-friendly-reminder-to-only-buy-your-refills-from-auth/1014556045764181/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook
- **URL:** https://www.facebook.com/61552820712644/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers website...
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook M-Gas - We're hiring in Kangemi! To apply, visit our careers ... M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... Samuel Namunga - We're hiring in Kakamega! To apply, visit... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED CALL (0784860605) | ANGUKIA OFFERS ZA # ...
- **URL:** https://www.facebook.com/groups/653145767783316/posts/709698335461392/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ANOTHER GIVEAWAY CHALLENGE! 🎉 Want ...
- **URL:** https://www.facebook.com/groups/844685979256352/posts/2667103730347892/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M GAS KENYA PIKA BILA STRESS CALL US or ...
- **URL:** https://www.facebook.com/groups/1006090580858866/posts/1414235310044389/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M Gas Kenya - Facebook
- **URL:** https://www.facebook.com/61573685076479/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0746447820', '0737559526'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT - Facebook
- **URL:** https://www.facebook.com/groups/3644210639219066/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Safaricom M Gas Kenya Offer with Free Delivery
- **URL:** https://www.facebook.com/groups/646056770252916/posts/1115783536613568/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0734030034'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Gas Refilling ( *all types of gas cylinders)* 📌 Gas complete ...
- **URL:** https://www.facebook.com/groups/295474376849804/posts/706699862393918/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LTD AGENT CALL (0738002423/+ ...
- **URL:** https://www.facebook.com/groups/289318563672325/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0738002423', '+254738286927'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED 0738002423
- **URL:** https://www.facebook.com/groups/886437143029196/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0738002423', '0738002423', '+254738286927'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### NAKURU BUYING AND SELLING LEGIT SECOND HAND ITEMS
- **URL:** https://www.facebook.com/groups/758358989008652/posts/1330249241819621/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Tvs and accessories | Heavy duty and industrial use Italian ...
- **URL:** https://www.facebook.com/groups/243925403509550/posts/1458213798747365/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Huge moving sale. Make offers - Facebook
- **URL:** https://www.facebook.com/marketplace/item/1056932299939082/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Must Sell - Make Offers - Facebook
- **URL:** https://www.facebook.com/commerce/listing/1305861917875215/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Other posts - Facebook
- **URL:** https://www.facebook.com/groups/893208048514351/posts/1252343285934157/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas
- **URL:** https://www.facebook.com/story.php?story_fbid=605893695526164&id=100083166169294
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### We're hiring in Kitale! To apply, visit our careers website or ...
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1066779485029859/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### We are Hiring M-Gas is seeking motivated and dynamic ...
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Jikokoa and kuniokoa Kenya supply | #PROMO!..PROMO!!..PROMO
- **URL:** https://www.facebook.com/groups/1202896060426633/posts/1321237625259142/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0780346507'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### TODAY AS INUA JAMII WE OFFER PROMOTION TO ALL ...
- **URL:** https://www.facebook.com/groups/1264476181144677/posts/1683706582554966/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | offer offers with only 550
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1025831539427440/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mgas Kenya are you interested What is the best
- **URL:** https://www.facebook.com/groups/abujacarbusiness/posts/2169648750202515/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ALMOST GIVEAWAY! 🏃🏃💨 💜💚 GET A QUALITY FOAM POA ...
- **URL:** https://www.facebook.com/groups/776036066350650/posts/1764225280865052/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0780163350'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT
- **URL:** https://www.facebook.com/groups/907555054290862/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS KENYA CALL 📞 OR WHATSAPP 0736965095 Low ...
- **URL:** https://www.facebook.com/groups/1327884598298290/posts/mgas-kenya-call-or-whatsapp-0736965095low-upfront-cost-low-initial-stove-deposit/1341723926914357/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0736965095', '0736965095'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT - Facebook
- **URL:** https://www.facebook.com/groups/3644210639219066/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ELDORET TOWN DIRECTORY AND MARKETING AGENT | MGAS KENYA …
- **URL:** https://www.facebook.com/groups/145297272312347/posts/2772549106253804/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0100594838'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### GITHUNGURI DAIRY FARMERS KENYA | Super ... - Facebook
- **URL:** https://www.facebook.com/groups/387081183783576/posts/558256573332702/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0100863356', '0753045802', '0753045802', '0753045802'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### HF Group Hiring In Nairobi 1. Scrum Master 2. Officer ...
- **URL:** https://www.facebook.com/groups/201801783357666/posts/2564973760373778/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

