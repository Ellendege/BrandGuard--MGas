## Key Business Intelligence
- **Timeframe:** 2025-09-09 06:07:20 UTC
- **Scan Terms:** `M-Gas | M Gas | M-Gas Kenya | mgas ke | mgas kenya`
- **Findings Summary:** Total 88 suspects | Critical 70 | High 0 | Medium 0 | Low 0
- **Top 3 Risks (one line each):**
  1) End of June Promo‼️ For every 1 tank of 11kg M-gas, you will ... — Facebook Page — Critical — https://www.facebook.com/61573549531758/posts/end-of-june-promo️for-every-1-tank-of-11kg-m-gas-you-will-get-a-free-350ml-of-di/122135078354784984/
  2) ✅PTPA ✅Fathers day special promo Awaits YOU ✅Avail our M ... — Facebook Group — Critical — https://www.facebook.com/groups/1241203062961165/posts/ptpa-fathers-day-special-promo-awaits-youavail-our-m-gas-lpg-from-may-12-to-15-a/2299753410439453/
  3) M-gas Kenya limited special offers — Facebook Group — Critical — https://www.facebook.com/groups/957825675925241/posts/mgas-with-special-offers-12-bob-tu-dial-479-ku-register-for-m-gas-leo-pikakwabei/1271854731188999/
- **Generated Files:**
  - Evidence CSV: evidence_workbook_20250909_060720.csv
  - Takedown Letter: takedown_complaint_20250909_060720.md
  - Intel Brief: threat_intelligence_brief_20250909_060720.md
- **Immediate Actions (max 3, imperative, with owner):**
  1) Submit takedown requests for 70 critical threats — **Owner:** Legal
  2) Brief customer service teams on 70 active threats — **Owner:** Fraud Ops

## Individual Threat Assessments

### End of June Promo‼️ For every 1 tank of 11kg M-gas, you will ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/61573549531758/posts/end-of-june-promo️for-every-1-tank-of-11kg-m-gas-you-will-get-a-free-350ml-of-di/122135078354784984/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### ✅PTPA ✅Fathers day special promo Awaits YOU ✅Avail our M ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1241203062961165/posts/ptpa-fathers-day-special-promo-awaits-youavail-our-m-gas-lpg-from-may-12-to-15-a/2299753410439453/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-gas Kenya limited special offers  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/mgas-with-special-offers-12-bob-tu-dial-479-ku-register-for-m-gas-leo-pikakwabei/1271854731188999/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/966324677961372/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Pm lng po Eros & Ezekiel Construction Services - Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/3177930242516926/posts/3605310029778943/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us at 0800 721 ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/photo.php?fbid=571958102253057&id=100083166169294&set=a.162860166496188
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Albay Gas Corporation - Facebook M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook GAS STATION BUSINESS PHILIPPINES | Facebook MADAM ANA M-GAS | Facebook Dominico LPG Trading | Binangonan - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/100063718218905/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Your safety is... - M-Gas Franchising Philippines | Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGASFranchising/posts/your-safety-is-everything-a-friendly-reminder-to-only-buy-your-refills-from-auth/1014556045764181/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M GAS LIPA MOS MOS AGENT NUMBER CALL OR WHATSAPP ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1135545828247507/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS KENYA LTD AGENT CALL (0738002423/+ ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/289318563672325/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We are Hiring M-Gas is seeking motivated and dynamic ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Albay Gas Corporation - Facebook Southern Gas Corporation Mindoro Branch | Calapan - Facebook MGAS NAGA MAIN - PALIT-TANGKE PROMO for only P930.00 ... M-Gas Franchising Philippines - GRAB THE CHANCE TO ... - Facebook GRAB THE CHANCE TO WIN A... - M-Gas Franchising Philippines Tierra Nevada Marketplace&Online Store | "One stop for all ... Be a part of the MGAS... - M-Gas Franchising Philippines  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/100063718218905/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS Special offers - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/events/526583930140239/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Kenyan 254 market Buy and sell | Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/913544077590514/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Look who’s happy! Our M-GAS 1st Anniver-saya Giveaway GRAND ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/mgaswincytrading/videos/look-whos-happy-our-m-gas-1st-anniver-saya-giveaway-grand-prize-winner-just-clai/329821892213407/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • name spoof variant • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Facebook M-gas Company Kenya - Facebook M Gas Kenya - Facebook M-GAS COMPANY LTD 0787813153 | Facebook M-GAS COMPANY 0787813153 - Facebook M-GAS KENYA LIMITED (0111944487) | Need assistance with your .....  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Your safety is... - M-Gas Franchising Philippines | Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGASFranchising/posts/your-safety-is-everything-a-friendly-reminder-to-only-buy-your-refills-from-auth/1014556045764181/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M GAS LIPA MOS MOS AGENT NUMBER CALL OR WHATSAPP ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1135545828247507/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS KENYA LTD AGENT CALL (0738002423/+ ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/289318563672325/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - We're hiring! To apply, visit our careers website...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Facebook M-Gas - We're hiring in Kangemi! To apply, visit our careers ... M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... Samuel Namunga - We're hiring in Kakamega! To apply, visit... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### charcoal stove promo is  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/307365138803135/posts/charcoal-stove-promo-is-still-going-onprice-is-large-3100medium-2600small-1850no/708675682005410/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS KENYA LIMITED (0752611017)  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M Gas Kenya offers gas delivery services  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1140874097101535/posts/1484917839363824/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### ANOTHER GIVEAWAY CHALLENGE! 🎉 Want ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/844685979256352/posts/2667103730347892/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M GAS KENYA PIKA BILA STRESS CALL US or ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1006090580858866/posts/1414235310044389/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M Gas Kenya - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/61573685076479/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us at 0780683 ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1441100829930644/posts/1552119652162094/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Gas Refilling ( *all types of gas cylinders)* 📌 Gas complete ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/295474376849804/posts/706699862393918/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Safaricom M Gas Kenya Offer with Free Delivery  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/646056770252916/posts/1115783536613568/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS KENYA LTD AGENT CALL (0738002423/+ ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/289318563672325/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • promo + giveaways
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS KENYA LIMITED 0738002423  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/886437143029196/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### NAKURU BUYING AND SELLING LEGIT SECOND HAND ITEMS ... - Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/758358989008652/posts/1330249241819621/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Tvs and accessories | Heavy duty and industrial use Italian ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/243925403509550/posts/1458213798747365/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We are Hiring M-Gas is seeking motivated and dynamic ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/359545889779700/posts/673762361691383/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-gas Lipa Mos's post  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/61558640182368/posts/we-are-hiring-in-nairobim-gas-is-seeking-motivated-and-dynamic-individuals-in-na/122160249488288006/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Modern COAST ltd  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/people/Modern-COAST-ltd/100092931717354/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Book your ticket know according to you ability. .NBVip class ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/100092931717354/posts/book-your-ticket-know-according-to-you-abilitynbvip-class-fares-will-vary-accord/106227452468613/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### SUNDAY SPECIAL OFFER🎊🎊 #MGAS HOT LINE ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1261574158883723/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS SAFARICOM TELL (SALES)0755415011  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/4135103280045771/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Other posts - Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/893208048514351/posts/1252343285934157/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Mgas Upishi Smart Ke - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/people/Mgas-Upishi-Smart-Ke/61559184901854/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Facebook M-Gas - Tumefika Kitengela! You can now get to enjoy... Mgas Upishi Smart - Facebook M-Gas - Pika smart na M-Gas clean, safe, na perfect kwa ... M-gas Kenyan - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Usipatwe off-Guard! Here are the simple steps to have M- ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1122355772805563/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Ukiwa na M-Gas budget ya gas is totally up to you. ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/photos/ukiwa-na-m-gas-budget-ya-gas-is-totally-up-to-you-imagine-uneza-pika-ugali-nyama/603558722426328/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We're hiring in Kitale! To apply, visit our careers website or ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1066779485029859/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Facebook M-Gas - We're hiring! To apply, visit our careers ... - Facebook M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... M-Gas - We're hiring in Kangemi! To apply, visit our careers ... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Jikokoa and kuniokoa Kenya supply | #PROMO!..PROMO!!..PROMO  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1202896060426633/posts/1321237625259142/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### TODAY AS INUA JAMII WE OFFER PROMOTION TO ALL ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1264476181144677/posts/1683706582554966/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS MKOPO 0106948302 | offer offers with only 550 ... - Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1025831539427440/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Mgas Kenya are you interested What is the best  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/abujacarbusiness/posts/2169648750202515/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### ALMOST GIVEAWAY! 🏃🏃💨 💜💚 GET A QUALITY FOAM POA ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/776036066350650/posts/1764225280865052/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/907555054290862/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS KENYA CALL 📞 OR WHATSAPP 0736965095 Low ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/1327884598298290/posts/mgas-kenya-call-or-whatsapp-0736965095low-upfront-cost-low-initial-stove-deposit/1341723926914357/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT - Facebook  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/3644210639219066/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### only 1550 u get your KOKO COOKER plus 2 free refills ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/946341743435549/posts/1240761353993585/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### only 1550 u get your KOKO COOKER plus 2 free refills ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/946341743435549/posts/1240222714047449/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS KENYA LIMITED 0738002423  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/886437143029196/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Mgas delivery services in Kenya with weekly payment plans  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/598504922024144/posts/980260800515219/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • unauthorized contact info • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** Potential IP misuse
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/966324677961372/posts/1468502757743559/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### (SAFARICOM)MGAS KENYA 🇰🇪⛽ M-Gas Requirements  —  **Facebook Group**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/groups/408874720439060/posts/1237173760942481/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • fake Facebook Group • missing official tagline
- **Confidence:** High
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - We're hiring! To apply, visit our careers website...  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook  —  **Facebook Page**  —  **Critical** (Score: 1.00)  —  **Priority P1**
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Takedown  (Reason: definitive impersonation)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Import and Export in Korea> - Facebook  —  **Facebook Group**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/groups/982277263105399/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Southern Gas Corporation Mindoro Branch | Calapan - Facebook Albay Gas Corporation - Facebook M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook GAS STATION BUSINESS PHILIPPINES | Facebook MADAM ANA M-GAS | Facebook Dominico LPG Trading | Binangonan - Facebook  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/OrMinIslandGas/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-gas Masagana, Argas, Prycegas and Superkalan Shine LPG Tank Your safety is... - M-Gas Franchising Philippines | Facebook ATHIRIVER KITENGELA ONLINE MARKET | Airbnb Kitengela - Facebook Samuel Grenier, page publique | See I'm at the gas station ...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/ArgasPrycegasMgasShinegasDealer/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MAKATI JOB HIRING | Facebook  —  **Facebook Group**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/groups/743819387078940/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### We are Hiring M-Gas is seeking motivated and dynamic ...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiring-m-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regi/688151853967014/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Southern Gas Corporation Mindoro Branch | Calapan - Facebook MGAS NAGA MAIN - PALIT-TANGKE PROMO for only P930.00 ... M-Gas Franchising Philippines - GRAB THE CHANCE TO ... - Facebook GRAB THE CHANCE TO WIN A... - M-Gas Franchising Philippines Tierra Nevada Marketplace&Online Store | "One stop for all ... Be a part of the MGAS... - M-Gas Franchising Philippines  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/OrMinIslandGas/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Just got lucky! Our Merry Christ-Manalo Giveaway 1st Prize ...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/mgaswincytrading/videos/just-got-lucky-our-merry-christ-manalo-giveaway-1st-prize-category-1-winner-uses/621714182418819/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Need assistance with your M-Gas? Call us at 0800...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/571958275586373/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us at 0800 721 ...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/need-assistance-with-your-m-gas-call-us-at-0800-721-148-our-dedicated-customer-c/571958275586373/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-gas Masagana, Argas, Prycegas and Superkalan Shine LPG Tank Your safety is... - M-Gas Franchising Philippines | Facebook We offer gas bottle refills & exchange... - Mica Durban North ... Fast AC/Refrigerator repairs&gas refills - Facebook Need gas? At Builders, we offer gas refill and exchange ... Does anyone refill gas bottles in town - Facebook Hip2Save - 64 ounces, $19.99 + $1.79 refills at my gas...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/ArgasPrycegasMgasShinegasDealer/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MAKATI JOB HIRING | Facebook  —  **Facebook Group**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/groups/743819387078940/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### PRYCE GAS LPG FREE DELIVERY | Facebook  —  **Facebook Group**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/groups/2546549678782280/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • promo + giveaways • missing official tagline
- **Confidence:** High
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas - Need assistance with your M-Gas? Call us at 0800...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/571958275586373/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Need assistance with your M-Gas? Call us at 0800 721 ...  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/need-assistance-with-your-m-gas-call-us-at-0800-721-148-our-dedicated-customer-c/571958275586373/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Alga cloth | Tanda - Facebook  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/61566467623470/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### Skyland Net Management | Semarang - Facebook Launcher - Facebook  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/skylandteam/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### M-Gas  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiring-in-nairobim-gas-is-seeking-motivated-and-dynamic-individuals-in-na/586877434094457/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** —
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.

### MGAS CUSTOMER SUPPORT - Facebook  —  **Facebook Page**  —  **Info** (Score: 0.00)  —  **Priority P5**
- **URL:** https://www.facebook.com/mgas.kenya.care/
- **Followers:** —   |   **Created:** —
- **Signals (max 3):** • missing official tagline
- **Confidence:** Medium
- **Recommended Action:** Ignore  (Reason: minimal threat level)
- **Compliance Flags:** Misleading branding
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only.