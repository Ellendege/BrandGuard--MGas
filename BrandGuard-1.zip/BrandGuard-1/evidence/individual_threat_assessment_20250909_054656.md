# Individual Threat Assessment Report
**Generated:** 2025-09-09 05:46:56 UTC  
**Analyst:** BrandGuard Enterprise OSINT System  
**Brand:** M-Gas Kenya

## Assessment Overview
This report provides detailed analysis of each detected threat against M-Gas Kenya's digital presence, with prioritized risk assessments and actionable recommendations for enforcement teams.

**Total Entities Analyzed:** 87  
**Assessment Methodology:** Automated OSINT + Professional Risk Scoring  
**Compliance:** Meta ToS compliant public data analysis  

## Individual Threat Profiles

### 🚨 Threat Profile #1: End of June Promo‼️ For every 1 tank of 11kg M-gas, you will ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/61573549531758/posts/end-of-june-promo️for-every-1-tank-of-11kg-m-gas-you-will-get-a-free-350ml-of-di/122135078354784984/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** End of June Promo ‼️ For every 1 tank of 11kg M-gas , you will get a free 350ml of Dishwashing Liquid. Promo runs until supplies last. Contact# (0998)...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #2: M-GAS Special offers - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/events/526583930140239/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Details Enjoy Quality Cooking Services From M - Gas :0752611017 at a minimum deposit Of 550/= Weekly Charges Of 35/= for 9mths Click On The Logo To Vi...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #3: Kenyan 254 market Buy and sell | Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/913544077590514/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Clinton Okumu Jan 3 💥FESTIVE SEASON OFFERS 💥 M - GAS KENYA PIKA BILA STRESS ..⭐CALL US 0762880299 ⭐WHATSAPP🔥0762880299 SAFARICOM M GAS IS A SAFARICOM ...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #4: Mr. M's gas giveaway with cars lined up

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1115480395465731/posts/1757254114621686/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Looks like Mr. M's is having a gas giveaway . . . cars are lined up for miles ... m's gas giveaway . . free gas giveaway near me. Other posts. Related...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #5: Willie Wilson's $1M gas giveaway starts in a few hours. Sarah ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/WGNMorningNews/videos/willie-wilsons-1m-gas-giveaway-starts-in-a-few-hours-sarah-jindra-has-the-latest/307075588218789/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Willie Wilson's $1 M gas giveaway starts in a few hours. Sarah Jindra has the latest traffic conditions. See the full list of where to get free fuel:....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #6: M-Gas - Facebook M Gas Kenya - Facebook M-gas Company Kenya - Facebook M-GAS COMPANY LTD 0787813153 | Facebook M-Gas Kenya> - Facebook M-GAS KENYA LIMITED (0111944487) | Need assistance with your .....

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M - Gas . 54,749 likes · 271 talking about this. M - Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans. M Gas Kenya May 13 T...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #7: Need assistance with your M-Gas? Call us

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Need assistance with your M-Gas ? Call us at 0111944487,or Any inquiry of our services. our dedicated customer care team is ready to support ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #8: M-gas now, Pay Later! Get 3 LPG refills for only 50 pesos per day ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://m.facebook.com/mgasconcepciontarlac/posts/m-gas-now-pay-laterget-3-lpg-refills-for-only-50-pesos-per-daycontact-us-0998583/122120095448783567/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M-gas now, Pay Later! Get 3 LPG refills for only 50 pesos per day! Contact us: 09985839393 · Avail our 10+1 PROMO‼️ Buy 10 11-kg M-gas refill and get ...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #9: Mascom Gas Trading Gas Refilling and Exchanges ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1651677148403782/posts/3990681181170022/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** OCR: MASCOM GAS TRADING CONVINIENTAND RELIABLE TERRARIF M GAS REFILLS & EXCHANGE GAS EQUIPMENT & ACCESSORIE FREE DELIVERY!!!...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #10: M GAS LIPA MOS MOS AGENT NUMBER CALL OR WHATSAPP ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1135545828247507/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M GAS LIPA MOS MOS AGENT NUMBER CALL OR WHATSAPP US ON 01034551594 > · Ukiwa na deposit ya 550/= Unapokea m-gas yako leo kila wiki utakua unalipia 35/...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #11: FURAHIA UPISHI ENJOY COOKING WITH M-GAS AGENT ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/359545889779700/posts/765024569231828/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M-gas profile picture. M-gas ▻ M GAS KENYA LIMITED CALL 0731129130 . Admin Aug 11 . . FURAHIA UPISHI ENJOY COOKING WITH M-GAS AGENT ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #12: We are Hiring M-Gas is seeking motivated and dynamic ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Hello Serge Pk Ibaaka, regularly check our website page at: https://mgas.ke/ under the Careers tab for the latest job openings! mgas.ke. M-Gas | ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #13: End of June Promo‼️ For every 1 tank of 11kg M-gas, you will ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/61573549531758/posts/end-of-june-promo️for-every-1-tank-of-11kg-m-gas-you-will-get-a-free-350ml-of-di/122135078354784984/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** End of June Promo ‼️ For every 1 tank of 11kg M-gas , you will get a free 350ml of Dishwashing Liquid. Promo runs until supplies last. Contact# (0998)...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #14: M-gas Kenya limited special offers

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/957825675925241/posts/mgas-with-special-offers-12-bob-tu-dial-479-ku-register-for-m-gas-leo-pikakwabei/1271854731188999/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** MGAS With Special offers 12 bob tu! Dial *479# ku register for M-Gas leo. #PikaKwaBeiYako #FurahiaUpishiWako #MGas Call 0752611017 Deposit ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #15: m-gas kenya limited (0752611017) | angukia offers za ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1310628327311639/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M-GAS KENYA LIMITED (0752611017) | ANGUKIA OFFERS ZA #MGAS. Public group. . 13K Members · Join group. M-GAS . profile picture. M-GAS ....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #16: Mr. M's gas giveaway with cars lined up

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1115480395465731/posts/1757254114621686/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Looks like Mr. M's is having a gas giveaway . . . cars are lined up for miles ... m's gas giveaway . . free gas giveaway near me. Other posts. Related...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #17: Willie Wilson's $1M gas giveaway starts in a few hours. Sarah ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/WGNMorningNews/videos/willie-wilsons-1m-gas-giveaway-starts-in-a-few-hours-sarah-jindra-has-the-latest/307075588218789/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Willie Wilson's $1 M gas giveaway starts in a few hours. Sarah Jindra has the latest traffic conditions. See the full list of where to get free fuel:....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #18: M-Gas - Facebook M-gas Company Kenya - Facebook M Gas Kenya - Facebook M-GAS COMPANY LTD 0787813153 | Facebook M-GAS COMPANY 0787813153 - Facebook M-GAS KENYA LIMITED (0111944487) | Need assistance with your .....

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M - Gas . 54,749 likes · 271 talking about this. M - Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans. ilikupokea huduma za...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #19: Albay Gas Corporation - Facebook MGAS - Welcome to the Official Page of M-GAS TAYTAY! We ... M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook MGAS CUSTOMER SUPPORT - Facebook We are built and ready to support... - Alacrity Solutions

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/100063718218905/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** false authority claims • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jun 10, 2021 · M-Gas Franchising Philippines Mar 22, 2021 Ms. Irma Gonzales has been an authorized reseller of Island Gas for years and last year, she...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #20: Your safety is... - M-Gas Franchising Philippines | Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGASFranchising/posts/your-safety-is-everything-a-friendly-reminder-to-only-buy-your-refills-from-auth/1014556045764181/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jan 31, 2022 · Your safety is EVERYTHING. 💯 A friendly reminder to only buy your refills from authorized distributors to ensure your tanks are new, we...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #21: M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/61552820712644/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M - GAS Kenya LTD Agent Call 0103676804, Westlands. 14 likes · 161 talking about this. Home Businesses...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #22: Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** 1 day ago · Let's get some gas for Kanicy Kamwaosh to make some porridge for her child. Ongwae Kerubo Dee please refill her M-gas account . #TeamOrwa...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #23: We are Hiring M-Gas is seeking motivated and dynamic ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regio/647850331330500/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Hello Serge Pk Ibaaka, regularly check our website page at: https://mgas.ke/ under the Careers tab for the latest job openings! mgas.ke. M-Gas | ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #24: charcoal stove promo is

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/307365138803135/posts/charcoal-stove-promo-is-still-going-onprice-is-large-3100medium-2600small-1850no/708675682005410/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** CHARCOAL STOVE PROMO IS STILL GOING ON!!! Price is Large 3100 ... M-GAS KENYA PIKA BILA STRESS ..⭐Call:+ ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #25: M GAS KENYA PIKA BILA STRESS 2️⃣ Burners=@550 ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/878566720242965/posts/1506157904150507/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • promo + giveaways
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M GAS KENYA PIKA BILA STRESS 2️⃣ Burners=@550 3️⃣ Burners ... PROMO PROMO PROMO pics, (08123504984).50% Promo is going on ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #26: M-GAS KENYA LIMITED (0752611017)

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/957825675925241/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M-GAS KENYA LIMITED is a Facebook group focused on providing pay-as-you-go cooking gas solutions to Kenyans. The group offers affordable cooking optio...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #27: M Gas Kenya offers gas delivery services

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1140874097101535/posts/1484917839363824/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M GAS COMPANY KENYA 0105030499 | M Gas Kenya offers gas delivery services. Public group. . 7.6K Members · Join group. MGAS COMPANY LTD KENYA ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #28: ANOTHER GIVEAWAY CHALLENGE! 🎉 Want ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/844685979256352/posts/2667103730347892/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ANOTHER GIVEAWAY CHALLENGE! Want to WIN a ... ANOTHER GIVEAWAY CHALLENGE! Want to WIN ... M-GAS KENYA LIMITED COMPANY, Mercy Abungu, Jonathan G....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #29: M GAS KENYA PIKA BILA STRESS CALL US or ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1006090580858866/posts/1414235310044389/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M GAS KENYA PIKA BILA STRESS CALL US or WHATSAPP + ... Ellen DeGeneres giveaway profile picture. Ellen DeGeneres giveaway . 5d ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #30: M Gas Kenya - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/61573685076479/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M Gas Kenya May 13 Tumefungua Nanyuki!😁 Pata M-Gas yako leo and get a chance to cook for your loved ones this festive season bila stress, usipitwe! To...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #31: Need assistance with your M-Gas? Call us

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ... support you every ... M-GAS KENYA LIMITED (0752611017) | Need assistance with your M-Gas? Call us. Public group....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #32: Need assistance with your M-Gas? Call us at 0780683 ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1441100829930644/posts/1552119652162094/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M-GAS KENYA LIMITED (0113986554) | Need ... our dedicated customer care team is ready to support you every step of the way! ... M-GAS KENYA LIMITED .....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #33: Gas Refilling ( *all types of gas cylinders)* 📌 Gas complete ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/295474376849804/posts/706699862393918/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ... refills Dealers in: Gas Refilling ( *all types of gas cylinders)* ... M-GAS KENYA PIKA BILA STRESS ..⭐Call ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #34: M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/61552820712644/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M - GAS Kenya LTD Agent Call 0103676804, Westlands. 14 likes · 161 talking about this. Home Businesses...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #35: KENYAN ENTREPRENEURS IN DIASPORA | M GAS KENYA ... - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1478775132392868/posts/3920559111547779/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M GAS KENYA PIKA KILA WAKATI...CALL. AGENT JIMMY CLIFF☎️..0100136093 SAFARICOM M GAS IS A SAFARICOM SPONSORED GAS ️ M GAS DEPOSIT 550 KSH COMES WITH.....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #36: M GAS KENYA PIKA BILA STRESS 2️⃣ Burners=@550 ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1735312360030079/posts/4410570792504209/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M GAS KENYA PIKA BILA STRESS 2️⃣ Burners=@550 3️⃣ Burners ... 1 hr . OCR: ጽህ! ل รคิอ รีสภาด M! SMARY МЕТЕЯ mgGas M! SMAR мгТА CRIA ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #37: M GAS KENYA PIKA KILA WAKATI...CALL US 0100-337-463 OR ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1848134362617928/posts/1853188662112498/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M GAS KENYA PIKA KILA WAKATI...CALL US 0100 ... M GAS KENYA PIKA KILA WAKATI ... HR Abbigail Kate profile picture. HR Abbigail Kate. Admin 56m ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #38: We are Hiring M-Gas is seeking motivated and dynamic ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/359545889779700/posts/673762361691383/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ... careers / Job Links: advanced#/jobs #Hiring #CustomerService ... M GAS KENYA PIKA BILA STRESS 2️⃣ Burners=@550 3️⃣ Burners=@1000 ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #39: We're hiring in Kitale! To apply, visit our careers website or ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1066779485029859/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** M-GAS KENYA LIMITED (0752611017) | We're hiring in Kitale! To ... To apply, visit our careers website or click on the link https:// careers ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #40: Modern COAST ltd

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/people/Modern-COAST-ltd/100092931717354/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Let them use promo code D7948150 when booking. NAIROBI ➡KIGALI daily ... Mgas Ke and 2 others · . 3 · · Modern COAST ltd profile picture. Modern COAST...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #41: Book your ticket know according to you ability. .NBVip class ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://m.facebook.com/100092931717354/posts/book-your-ticket-know-according-to-you-abilitynbvip-class-fares-will-vary-accord/106227452468613/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Let them use promo code D7948150 when booking. NAIROBI ➡KIGALI ... Mgas Ke and 2 others · . 3 · . Related Pages. Mogo loan motorcycle ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #42: Huge moving sale. Make offers - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/marketplace/item/1056932299939082/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Please dm for prices and or make offer - all must go! Thanks for looking shoes are new size 11 women - $40 Wall art make offers Round wood Table $60 A...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #43: Must Sell - Make Offers - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/commerce/listing/1305861917875215/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** $1 per item · In Stock Listed on Friday in Garden City, MO Description Make offers Must pick up in Garden City MO this weekend CASH ONLY More items in...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #44: Other posts - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/893208048514351/posts/1252343285934157/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ... giveaway , Selaelo C Machabaphala, Mma Karabo, Lepelle Khutso Khutsi ... Mgas Ke , Moss Chuma, Jonathan Brize, Mdogo Mdogo Smartphone ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #45: Mgas Upishi Smart Ke - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/people/Mgas-Upishi-Smart-Ke/61559184901854/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Nov 22, 2024 · to serve you. For any customer service needs, call us on our toll- free Customer Care number at 0105 004775 chat with us on WhatsApp at...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #46: M-Gas - Facebook M-Gas - Tumefika Kitengela! You can now get to enjoy... Mgas Upishi Smart - Facebook M-Gas - Pika smart na M-Gas clean, safe, na perfect kwa ... M-gas Kenyan - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** mgas .ke M - Gas Aug 15 Are you passionate about creating sustainable impact and driving results ? We’re looking for enthusiastic personnel to join ou...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #47: FurahiaUpishiWako #cleancooking #affordablecooking #MGAS

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://m.facebook.com/MGasKenya/photos/furahiaupishiwako-cleancooking-affordablecooking-mgas/605610748887792/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** We'll ensure that your request is escalated to the depot serving your area for prompt support . ... Visit website yetu tps:// mgas.ke / u-learn more ....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #48: M-Gas - Ukiwa na M-Gas budget ya gas is totally up to you. ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/photos/ukiwa-na-m-gas-budget-ya-gas-is-totally-up-to-you-imagine-uneza-pika-ugali-nyama/603558722426328/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Hello Steve Kariuki M-Gas does not request any amount for refills or "updating" your meter. ... Apply Now: Visit our career portal at https:// mgas. k...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #49: Beware of Fraudsters purporting to work for M-Gas! We will ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/beware-of-fraudsters-purporting-to-work-for-m-gas-we-will-never-ask-you-for-any-/504629532319248/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** We registered on Saturday here at gatunduri village in Embu..the agent was to come n deliver the gas n cookers but hakukam. ... careers. mgas.ke ....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #50: M-Gas

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://m.facebook.com/story.php?story_fbid=621403657308501&id=100083166169294
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** mgas.ke . Nurturing Talent, Building ... Mc Blaxie the Hr doesn't listen to workers they ... mgas. ke /careers/ Job Links: https://mgas.seamlesshiring...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #51: M-Gas - Facebook M-Gas - We're hiring! To apply, visit our careers ... - Facebook M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... M-Gas - We're hiring in Kangemi! To apply, visit our careers ... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** mgas .ke M- Gas Aug 15 Are you passionate about creating sustainable impact and driving results ? We’re looking for enthusiastic personnel to join our...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #52: M-Gas - We're hiring! To apply, visit our careers ... - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jul 10, 2023 · We're hiring! To apply, visit our careers website or click on the link https:// careers . mgas . ke / #FurahiaUpishiWako #cleancooking ...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #53: Jikokoa and kuniokoa Kenya supply | #PROMO!..PROMO!!..PROMO

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1202896060426633/posts/1321237625259142/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Jan 8, 2024 · Josline Esendi 6d Ni ya leo 🤌Mgas kenya imekuja na offer kibao Ukiwa na deposit ya 550 pekee tunakupea gas pamoja na 13kg clynder uwe uk...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #54: 0782946741 Mgas kenya imekuja na offer kibao

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/2502306723286057/posts/2900756940107698/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • promo + giveaways
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ... Mgas kenya imekuja na offer kibao ... 0782946741 Mgas kenya imekuja na offer kibao ... Promo ... Promo ... Promo MR EMMANUEL CYLINDER GAS ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #55: MGAS OFFERS YOU BEST SERVICES EVER!! DEPOSIT ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/653145767783316/posts/740289502402275/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** MGAS OFFERS YOU BEST SERVICES EVER!! DEPOSIT/2burber 550 shillings ... Mgas Kenya and 2 others · . 3 · 5 · . Anne Mary. Admin 2d . ....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #56: MGAS KENYA LIMITED SERVICE 0780163350 | Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1098251691916760/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ANGUKIA OFFERS ZA MGAS. DEPOSIT, 2 burners 550 shillings Weekly Installment 35Bob. CALL US OR What's App 0780163350 · Robert Bakari▻ MGAS KENYA LIMITE...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #57: Mgas Kenya are you interested What is the best

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/abujacarbusiness/posts/2169648750202515/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Mgas Kenya are you interested What is the best ... Mgas Kenya are you interested What is the best type you ... *Sallah giveaway !!!* Super sharp C350....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #58: ALMOST GIVEAWAY! 🏃🏃💨 💜💚 GET A QUALITY FOAM POA ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/776036066350650/posts/1764225280865052/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** DEALS POA ZA MATTRESS – ALMOST GIVEAWAY ... GIVEAWAY ... Non carbon dioxide FurahiaUpishiWako MGAS KENYA LIMITED SERVICE 0780163350 delivery countrywi...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #59: MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/907555054290862/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT > ... The MGAS CUSTOMER CARE SERVICE AND ORDER ... Furahia Upishi poa na Mgas Kenya . Call/whatsapp ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #60: MGAS KENYA CALL 📞 OR WHATSAPP 0736965095 Low ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1327884598298290/posts/mgas-kenya-call-or-whatsapp-0736965095low-upfront-cost-low-initial-stove-deposit/1341723926914357/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** MGAS KENYA CALL OR WHATSAPP 0736965095 Low ... MGAS KENYA CALL OR WHATSAPP 0736965095 Low ... Customer Care . DEPOSIT 550 shillings 25 shillings ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #61: M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/966324677961372/posts/1468654497728385/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ... Support FREE Delivery – We bring it straight to you! ... MGAS KENYA profile picture. MGAS KENYA ▻M-GAS SAFARICOM KINDLY CALL OR TEXT ON ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #62: MGAS KENYA 0739557241

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1573778559875972/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Mgas Kenya are you interestedWhat is the best ... Mgas Kenya are you interestedWhat is the best type you want the most 1. ... Message Customer Support...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #63: only 1550 u get your KOKO COOKER plus 2 free refills ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/946341743435549/posts/1240761353993585/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** @ only 1550 u get your KOKO COOKER plus 2 free refills , inbox or reach us on 0103619903 we deliver country wide via parcels ; Caleb Ndisio ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #64: only 1550 u get your KOKO COOKER plus 2 free refills ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/946341743435549/posts/1240222714047449/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** only 1550 u get your KOKO COOKER plus 2 free refills , inbox or reach us on 0103619903 we deliver country wide via parcels....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #65: ELDORET TOWN DIRECTORY AND MARKETING AGENT | MGAS KENYA ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/145297272312347/posts/2772549106253804/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** MGAS KENYA SPECIAL OFFERS KWA KILA MTU? DEPOSIT IS NOW KSH.350/= DAILY PAYMENT KSH.20 BOB /= CALL US 0100594838...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #66: GITHUNGURI DAIRY FARMERS KENYA | Super ... - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/387081183783576/posts/558256573332702/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** unauthorized contact info • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ⚠️ Unauthorized contact information detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** Potential IP misuse

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Join MGAS KENYA : 0100863356 2.3K members Join Copia offers 14K members Join CITIZEN DUKA 1.8K members Join Delamere FARM Naivasha 0753045802 GITHUNGU...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #67: (SAFARICOM)MGAS KENYA 🇰🇪⛽ M-Gas Requirements

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/408874720439060/posts/1237173760942481/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Mgas Kenya are you interested What is the best type you want ... Hr Opiyo Helpdesk Opiyo profile picture. Hr Opiyo Helpdesk Opiyo. 15h ......
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #68: Mgas Kenya are you interestedWhat is the best type you want ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/359545889779700/posts/mgas-kenya-are-you-interestedwhat-is-the-best-type-you-want-the-most-2-burners-5/694431352957817/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** fake Facebook Group • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** Mgas Kenya are you interestedWhat is the best ... Mgas Kenya are you interestedWhat is the best type ... 1 hr . M GAS LIPA MOS MOS KENYA. . Author. . ...
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 🚨 Threat Profile #69: HF Group Hiring In Nairobi 1. Scrum Master 2. Officer ...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/201801783357666/posts/2564973760373778/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Critical (Score: 1.00/1.00)
- **Priority:** P1 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Takedown
- **Justification:** Definitive Impersonation
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Immediate

**Technical Notes:**
- **About/Description:** ke/ careers /jobsListing #HFCareers #NairobiJobs #BankingJobs #ScrumMaster #KenyaJobs ... Mgas Kenya . 56m . M GAS KENYA PIKA BILA STRESS 1️⃣ Burner ....
- **Risk Score Breakdown:** 16/16 (legacy scale) = 1.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #70: M-Gas Concepcion Tarlac

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/mgasconcepciontarlac/posts/avail-our-101-promo️buy-10-11-kg-m-gas-refill-and-get-1-free-for-only-php-9400ex/122113851290783567/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Avail our 10+1 PROMO ‼️ Buy 10 11-kg M-gas refill and get 1 free for only PHP 9400! "Exact Weight is our Business." Sto Cristo, Concepcion ......
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #71: M-Gas - Need assistance with your M-Gas? Call us at 0800...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/571958275586373/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Need assistance with your M - Gas ? Call us at 0800 721 148, our dedicated customer care team is ready to support you every step of the way!......
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #72: Need assistance with your M-Gas? Call us at 0800 721 ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/need-assistance-with-your-m-gas-call-us-at-0800-721-148-our-dedicated-customer-c/571958275586373/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Need assistance with your M-Gas ? Call us at 0800 721 148, our dedicated customer care team is ready to support you every step of the way!...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #73: MAKATI JOB HIRING | Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/743819387078940/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** ☑️ Preferably with HR experience, but fresh graduates are welcome to apply ☑️ Proficient in MS Office Applications ☑️ Has excellent oral and written c...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #74: We are Hiring M-Gas is seeking motivated and dynamic ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiring-m-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regi/688151853967014/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** ... ://mgas.ke/ careers / or Job Links: https://mgas. seamlesshiring.com/h/advanced#/jobs and apply. mgas.ke. Careers | M-Gas . 3 mos. Evans Opiyo....
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #75: M-Gas Concepcion Tarlac

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/mgasconcepciontarlac/posts/avail-our-101-promo️buy-10-11-kg-m-gas-refill-and-get-1-free-for-only-php-9400ex/122113851290783567/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** promo + giveaways • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Avail our 10+1 PROMO ‼️ Buy 10 11-kg M-gas refill and get 1 free for only PHP 9400! "Exact Weight is our Business." Sto Cristo, Concepcion ......
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #76: M-Gas - Need assistance with your M-Gas? Call us at 0800...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/571958275586373/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Need assistance with your M - Gas ? Call us at 0800 721 148, our dedicated customer care team is ready to support you every step of the way!......
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #77: Southern Gas Corporation Mindoro Branch | Calapan - Facebook Albay Gas Corporation - Facebook MGAS - Welcome to the Official Page of M-GAS TAYTAY! We ... M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook MGAS CUSTOMER SUPPORT - Facebook We are built and ready to support... - Alacrity Solutions

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/OrMinIslandGas/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** false authority claims • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Thank you for the trust and support , mr. Ritchard! We are here to support you throughout your M-GAS Journey. We are still open here in Calapan Orient...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #78: M-gas Masagana, Argas, Prycegas and Superkalan Shine LPG Tank Your safety is... - M-Gas Franchising Philippines | Facebook We offer gas bottle refills & exchange... - Mica Durban North ... Fast AC/Refrigerator repairs&gas refills - Facebook Need gas? At Builders, we offer gas refill and exchange ... Does anyone refill gas bottles in town - Facebook Hip2Save - 64 ounces, $19.99 + $1.79 refills at my gas...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/ArgasPrycegasMgasShinegasDealer/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** M - gas Masagana, Argas, Prycegas and Superkalan Shine LPG Tank. 1,802 likes · 1 talking about this. We deliver along NAIC CAVITE LPG SGAS ARGAS PRYCE...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #79: SAFARICOM M-GAS AGENT - Facebook

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/safaricommgasagent/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** SAFARICOM M - GAS AGENT is on Facebook. Join Facebook to connect with SAFARICOM M - GAS AGENT and others you may know. Facebook gives people the power...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #80: MAKATI JOB HIRING | Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/743819387078940/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** ☑️ Preferably with HR experience, but fresh graduates are welcome to apply ☑️ Proficient in MS Office Applications ☑️ Has excellent oral and written c...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #81: We are Hiring M-Gas is seeking motivated and dynamic ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiring-m-gas-is-seeking-motivated-and-dynamic-individuals-in-nairobi-regi/688151853967014/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** ... ://mgas.ke/ careers / or Job Links: https://mgas. seamlesshiring.com/h/advanced#/jobs and apply. mgas.ke. Careers | M-Gas . 3 mos. Evans Opiyo....
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #82: M-Gas - Need assistance with your M-Gas? Call us at 0800...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/571958275586373/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Need assistance with your M - Gas ? Call us at 0800 721 148, our dedicated customer care team is ready to support you every step of the way!......
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #83: ATHIRIVER KITENGELA ONLINE MARKET | Airbnb Kitengela - Facebook

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/Athiriver/posts/24569357419366624/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** High (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** false authority claims • missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** High (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Aug 31, 2025 · - Pressure pump refills the top tank automatically. - Reliable water supply available 24/7. - Common perimeter electric fence. - Securi...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #84: Need assistance with your M-Gas? Call us at 0800 721 ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/need-assistance-with-your-m-gas-call-us-at-0800-721-148-our-dedicated-customer-c/571958275586373/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Need assistance with your M-Gas? Call us at 0800 721 148, our dedicated customer care team is ready to support you every step of the way!...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #85: We are Hiring! M-Gas is seeking motivated and dynamic ...

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiringm-gas-is-seeking-motivated-and-dynamic-individuals-to-join-our-team/591689360279931/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** Misleading branding

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** ... mgas.ke /careers/ All open jobs can be viewed under-Check Ready Jobs ... Ndege Millie To speak to an M-Gas agent kindly call us free on ......
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #86: M-Gas

**Basic Information:**
- **Platform:** Facebook Page
- **URL:** https://www.facebook.com/MGasKenya/posts/we-are-hiring-in-nairobim-gas-is-seeking-motivated-and-dynamic-individuals-in-na/586877434094457/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** ... mgas.ke /careers/Job Links: Motorized Technical Sales Representative ... HR team once shortlisted applicants are contacted. 8 mos. Quincy ......
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---

### 📝 Threat Profile #87: Join Careers Crafters Network for more job vacancies, don`...

**Basic Information:**
- **Platform:** Facebook Group
- **URL:** https://www.facebook.com/groups/1548824975418165/posts/3632644573702851/
- **Followers:** Unknown
- **Discovery Method:** OSINT search via public API

**Risk Assessment:**
- **Risk Level:** Info (Score: 0.00/1.00)
- **Priority:** P5 (Business criticality ranking)
- **Confidence:** Medium (Assessment reliability)

**Threat Indicators:**
- **Detected Signals:** missing official tagline
- **Tagline Analysis:** ❌ Official tagline missing/altered
- **Contact Analysis:** ✅ No unauthorized contacts detected

**Business Impact:**
- **Recommended Action:** Ignore
- **Justification:** Minimal Threat Level
- **Compliance Concerns:** —

**Legal Considerations:**
- **Evidence Quality:** Medium (for potential takedown requests)
- **Enforcement Priority:** Low

**Technical Notes:**
- **About/Description:** Join Careers Crafters Network for more job vacancies, don`t miss ... Join Careers Crafters Network ... @everyone Ni ya leo Mgas kenya imekuja na offer...
- **Risk Score Breakdown:** 0/16 (legacy scale) = 0.00 (normalized)
- **Detection Timestamp:** 2025-09-09 05:46:56 UTC

---


## Summary & Next Steps

**Assessment Complete:** 2025-09-09 05:46:56 UTC
**Total Analyzed:** 87 entities
**Enforcement Ready:** 69 high-priority cases

**Recommended Actions:**
1. **Legal Team:** Review P1/P2 priority cases for takedown requests
2. **Communications:** Prepare customer advisories if fraud indicators present  
3. **Monitoring:** Continue surveillance for new impersonation attempts

**Report Distribution:**
- Legal Counsel (for enforcement decisions)
- Brand Protection Team (for strategic planning)  
- Customer Support (for fraud awareness)

---
*This report contains confidential business intelligence. Distribution restricted to authorized personnel.*
