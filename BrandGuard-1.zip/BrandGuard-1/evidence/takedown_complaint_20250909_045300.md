# Meta Takedown Request - M-Gas Kenya Brand Protection

**Generated:** 2025-09-09T04:53:00.409290  
**Complainant:** M-Gas Kenya Brand Protection Team  
**Grounds:** Trademark infringement, brand impersonation  

## Official Brand Reference
- **Page Name:** M-Gas
- **Entity Type:** Page 
- **Domain:** mgas.ke
- **Tagline:** "M-Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans."
- **Followers:** ~65,000

## Violating Entities (75 flagged)

### End of June Promo‼️ For every 1 tank of 11kg M-gas, you will ...
- **URL:** https://www.facebook.com/61573549531758/posts/end-of-june-promo️for-every-1-tank-of-11kg-m-gas-you-will-get-a-free-350ml-of-di/122135078354784984/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ENJOY COOKING WITH M~GAS💥 ✅️Deposit 550 shillings ...
- **URL:** https://www.facebook.com/groups/878566720242965/posts/1526146258818338/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0916422452'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Special offers - Facebook
- **URL:** https://www.facebook.com/events/526583930140239/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017', '0752611017', '0101447717'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Kenyan 254 market Buy and sell | Facebook
- **URL:** https://www.facebook.com/groups/913544077590514/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0762880299', '0762880299'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS -PAY-AS-YOU COOK (ENJOY COOKING & CHRISTMAS OFFERS ...
- **URL:** https://www.facebook.com/groups/1220026285699831/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['+254736490072'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### SKYWAVE ADVERTS> - Facebook
- **URL:** https://www.facebook.com/groups/1209168100409027/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Pm lng po Eros & Ezekiel Construction Services - Facebook
- **URL:** https://www.facebook.com/groups/3177930242516926/posts/3605310029778943/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook M Gas Kenya - Facebook M-gas Company Kenya - Facebook M-GAS COMPANY LTD 0787813153 | Facebook M-GAS KENYA LIMITED (0111944487) | Need assistance with your ..... M gas - M gas | Facebook
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0746447820', '0737559526', '0106926827', '0104778819', '0787813153', '0111944487', '0786019526', '0782787599'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M Gas Kenya - Facebook
- **URL:** https://www.facebook.com/61573685076479/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0746447820', '0737559526'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Albay Gas Corporation - Facebook M-Gas Franchising Philippines - Facebook M.Gas Heating & Plumbing | Oldbury - Facebook GAS STATION BUSINESS PHILIPPINES | Facebook MADAM ANA M-GAS | Facebook Dominico LPG Trading | Binangonan - Facebook
- **URL:** https://www.facebook.com/100063718218905/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-gas now, Pay Later! Get 3 LPG refills for only 50 pesos per day ...
- **URL:** https://m.facebook.com/mgasconcepciontarlac/posts/m-gas-now-pay-laterget-3-lpg-refills-for-only-50-pesos-per-daycontact-us-0998583/122120095448783567/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0998583939'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Safaricom and M-Gas launched the revolutionary, prepaid ...
- **URL:** https://www.facebook.com/groups/954366519042739/posts/1170291037450285/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['+254107453715'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mascom Gas Trading Gas Refilling and Exchanges ...
- **URL:** https://www.facebook.com/groups/1651677148403782/posts/3990681181170022/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook
- **URL:** https://www.facebook.com/61552820712644/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS MARKETPLACE (+254107453715) | Facebook
- **URL:** https://www.facebook.com/groups/954366519042739/posts/1331643561315031/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Amos Orwa - Let's get some gas for Kanicy Kamwaosh to make ...
- **URL:** https://www.facebook.com/Saintamoe/posts/10230992789819396/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ALGORITMA FB Pro | Yang membutuhkan. | Facebook
- **URL:** https://www.facebook.com/groups/88876988423/posts/10161931580573424/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers website...
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Albay Gas Corporation - Facebook
- **URL:** https://www.facebook.com/100063718218905/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS NAGA MAIN - PALIT-TANGKE PROMO for only P930.00 ...
- **URL:** https://www.facebook.com/mgaskalawakan/posts/palit-tangke-promo-for-only-p93000thank-you-po-sa-pag-avail-ng-palit-tangke-prom/130724526410794/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Special offers - Facebook
- **URL:** https://www.facebook.com/events/526583930140239/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0752611017', '0752611017', '0101447717'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Kenyan 254 market Buy and sell | Facebook
- **URL:** https://www.facebook.com/groups/913544077590514/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0762880299', '0762880299'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS -PAY-AS-YOU COOK (ENJOY COOKING & CHRISTMAS OFFERS ...
- **URL:** https://www.facebook.com/groups/1220026285699831/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['+254736490072'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### SKYWAVE ADVERTS> - Facebook
- **URL:** https://www.facebook.com/groups/1209168100409027/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Pm lng po Eros & Ezekiel Construction Services - Facebook
- **URL:** https://www.facebook.com/groups/3177930242516926/posts/3605310029778943/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us at 0800 721 ...
- **URL:** https://www.facebook.com/photo.php?fbid=571958102253057&id=100083166169294&set=a.162860166496188
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0111944487'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Need assistance with your M-Gas? Call us
- **URL:** https://www.facebook.com/groups/957825675925241/posts/1123317796042694/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0111944487'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Did you know that our self-support USSD allows ...
- **URL:** https://www.facebook.com/photo.php?fbid=304518022330401&id=100083166169294&set=a.125748330207372
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Your safety is... - M-Gas Franchising Philippines | Facebook
- **URL:** https://www.facebook.com/MGASFranchising/posts/your-safety-is-everything-a-friendly-reminder-to-only-buy-your-refills-from-auth/1014556045764181/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook
- **URL:** https://www.facebook.com/61552820712644/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS MARKETPLACE (+254107453715) | Facebook
- **URL:** https://www.facebook.com/groups/954366519042739/posts/1331643561315031/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas 📍: #Nairobi #Internship ⏱️ Deadline: 11th Aug ...
- **URL:** https://www.facebook.com/campusbizke/posts/-hr-digital-and-engagement-internship-m-gas-nairobi-internship-️-deadline-11th-a/1089234726681358/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers website...
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook M-Gas - We're hiring in Kangemi! To apply, visit our careers ... M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ... Samuel Namunga - We're hiring in Kakamega! To apply, visit... Lawyers Rule!! (Original) | https://careers.mgas.ke/careers ... Ndarugu Ward United Forum | https://careers.mgas.ke/careers ...
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring in Kangemi! To apply, visit our careers ...
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-in-kangemi-to-apply-visit-our-careers-website-or-click-on-the-link-h/254082490707288/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### charcoal stove promo is
- **URL:** https://www.facebook.com/groups/307365138803135/posts/charcoal-stove-promo-is-still-going-onprice-is-large-3100medium-2600small-1850no/708675682005410/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M GAS KENYA PIKA BILA STRESS 2️⃣ Burners=@550 ...
- **URL:** https://www.facebook.com/groups/878566720242965/posts/1506157904150507/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0812350498'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### We Are Giving You M-gas Cylinder Of 13Kg With 2 Burners ...
- **URL:** https://www.facebook.com/groups/613972561204927/posts/658667833402066/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0707136966'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED CALL (0784860605) | ANGUKIA OFFERS …
- **URL:** https://www.facebook.com/groups/653145767783316/posts/709698335461392/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED (0113986554) | ANGUKIA OFFERS …
- **URL:** https://www.facebook.com/groups/1441100829930644/posts/1605724880134904/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0113986554', '0113986554'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT
- **URL:** https://www.facebook.com/groups/3644210639219066/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### NEW THOME WA KANZIKO | Facebook
- **URL:** https://www.facebook.com/groups/1893650024182070/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS Kenya LTD Agent Call 0103676804 | Westlands - Facebook
- **URL:** https://www.facebook.com/61552820712644/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### KENYAN ENTREPRENEURS IN DIASPORA | M GAS KENYA
- **URL:** https://www.facebook.com/groups/1478775132392868/posts/3920559111547779/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0100136093'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### NEW THOME WA KANZIKO | Facebook
- **URL:** https://www.facebook.com/groups/1893650024182070/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0103676804'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### NAKURU BUYING AND SELLING LEGIT SECOND HAND …
- **URL:** https://www.facebook.com/groups/758358989008652/posts/1330249241819621/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Tvs and accessories | Heavy duty and industrial use Italian ...
- **URL:** https://www.facebook.com/groups/243925403509550/posts/1458213798747365/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring in Kangemi! To apply, visit our careers ...
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-in-kangemi-to-apply-visit-our-careers-website-or-click-on-the-link-h/254082490707288/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Huge moving sale. Make offers - Facebook
- **URL:** https://www.facebook.com/marketplace/item/1056932299939082/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Must Sell - Make Offers - Facebook
- **URL:** https://www.facebook.com/commerce/listing/1305861917875215/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Make offers ! Gown, casual wear, swimsuits - Facebook
- **URL:** https://www.facebook.com/marketplace/item/1105158138140159/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mgas Upishi Smart Ke - Facebook
- **URL:** https://www.facebook.com/people/Mgas-Upishi-Smart-Ke/61559184901854/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook M-Gas - Tumefika Kitengela! You can now get to enjoy... Mgas Upishi Smart - Facebook M-Gas - Pika smart na M-Gas clean, safe, na perfect kwa ... M-gas Kenyan - Facebook
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0800721148', '0105004775', '0106252780'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mgas Upishi Smart - Facebook
- **URL:** https://www.facebook.com/people/Mgas-Upishi-Smart/61558534593897/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0105004775', '0106252780'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Launcher - Facebook
- **URL:** https://www.facebook.com/people/Launcher/100078272850239/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS COMPANY LTD 0787813153 | We're hiring! To apply, visit ...
- **URL:** https://www.facebook.com/groups/1416701029150257/posts/1504524563701236/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Jikokoa and kuniokoa Kenya supply | #PROMO!..PROMO!!..PROMO
- **URL:** https://www.facebook.com/groups/1202896060426633/posts/1321237625259142/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0780346507'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | @highlight offer offers ... - Facebook
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1024560116221249/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS MKOPO 0106948302 | offer offers with only 550
- **URL:** https://www.facebook.com/groups/781287047215225/posts/1025831539427440/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0106948302'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS KENYA LIMITED CALL (0784860605) | ANGUKIA OFFERS …
- **URL:** https://www.facebook.com/groups/653145767783316/posts/709698335461392/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - Facebook MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT> - Facebook Mgas kenya call 0750279398 - Facebook Genuine M-Gas Kenya L.T.D Helpline number 0101140606 | Facebook MGAS CUSTOMER SUPPORT - Facebook M-Gas Kenya | Facebook
- **URL:** https://www.facebook.com/MGasKenya/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0755928849', '0750279398', '0750279398', '0101140606', '0736965095'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS CUSTOMER CARE SERVICE AND ORDER PLACEMENT> - Facebook
- **URL:** https://www.facebook.com/groups/907555054290862/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0755928849'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mgas kenya call 0750279398 - Facebook
- **URL:** https://www.facebook.com/profile.php/?id=61576755506667
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0750279398', '0750279398'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### MGAS KENYA QUICK RESPONSE CUSTOMER SUPPORT - Facebook
- **URL:** https://www.facebook.com/groups/3644210639219066/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-GAS SAFARICOM KINDLY CALL OR TEXT ON WHAT'S ...
- **URL:** https://www.facebook.com/groups/966324677961372/posts/1468654497728385/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### ELDORET TOWN DIRECTORY AND MARKETING AGENT | MGAS KENYA ...
- **URL:** https://www.facebook.com/groups/145297272312347/posts/2772549106253804/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0100594838'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### GITHUNGURI DAIRY FARMERS KENYA | Super ... - Facebook
- **URL:** https://www.facebook.com/groups/387081183783576/posts/558256573332702/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': ['0100863356', '0753045802'], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### Mosoriot Nduthi Culture | Facebook
- **URL:** https://www.facebook.com/groups/926981005505257/
- **Type:** Group
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers website...
- **URL:** https://www.facebook.com/MGasKenya/posts/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210607761143/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring! To apply, visit our careers ... - Facebook
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-to-apply-visit-our-careers-website-or-click-on-the-link-httpscareers/250210587761145/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

### M-Gas - We're hiring in Kangemi! To apply, visit our careers ...
- **URL:** https://www.facebook.com/MGasKenya/photos/were-hiring-in-kangemi-to-apply-visit-our-careers-website-or-click-on-the-link-h/254082490707288/
- **Type:** Page
- **Risk Score:** 16/16 (Likely Impersonator)
- **Violations:** 
  - Brand impersonation (official tagline absent)
  - Misleading representation of services
  - Suspicious contact patterns: {'phones': [], 'emails': [], 'whatsapp': [], 'mpesa_paybill_or_till': []}
- **Evidence:** Public metadata analysis, OSINT discovery

