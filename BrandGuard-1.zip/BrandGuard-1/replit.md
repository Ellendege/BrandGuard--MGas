# Overview

BrandGuard is an enterprise-grade OSINT (Open Source Intelligence) brand protection system specifically designed for M-Gas Kenya. The application provides automated detection and analysis of Facebook pages and groups that impersonate or misuse the M-Gas brand. It generates comprehensive threat intelligence reports, takedown complaint documentation, and evidence packages for enforcement teams. The system operates in strict compliance with Meta's Terms of Service by using only public data interfaces without circumventing authentication or engaging in unauthorized scraping.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Core Application Structure
The system is built as a single-file Python application using Gradio for the web interface. The main application (`main.py`) contains all business logic, scoring algorithms, and report generation functionality. The architecture follows a functional programming approach with clearly separated concerns for data collection, analysis, and reporting.

## Brand Protection Engine
The core functionality revolves around a sophisticated scoring algorithm that evaluates Facebook entities against known authentic brand signals. The system maintains a ground truth reference for the official M-Gas page and compares discovered entities against these authentic characteristics. Risk scoring uses both positive signals (matching official tagline, correct domain links) and negative signals (suspicious naming patterns, unauthorized contact information, fake promotional content).

## Data Processing Pipeline
The application implements a three-stage processing pipeline: (1) OSINT data collection using public APIs, (2) risk assessment and scoring using the BrandGuard algorithm, and (3) multi-format report generation. The scoring system categorizes threats into risk levels (Critical, High, Medium, Low, Info) with corresponding priority assignments for enforcement teams.

## Report Generation System
The system generates multiple output formats optimized for different stakeholders: threat intelligence briefs in Markdown for technical teams, takedown complaint packages formatted for Meta's enforcement processes, individual threat assessments with detailed evidence, and Excel workbooks for data analysis. All reports include compliance notes emphasizing adherence to platform terms of service.

## Evidence Management
Generated reports and evidence are systematically organized in an `evidence/` directory with timestamp-based naming conventions. The system maintains audit trails for all analysis activities and preserves evidence integrity for potential legal proceedings.

# External Dependencies

## Search and Data Collection
- **DDGS (DuckDuckGo Search)**: Primary OSINT data collection engine for discovering potentially infringing Facebook content through public search interfaces
- **Pandas**: Data manipulation and analysis for processing search results and generating structured datasets

## Document Generation
- **OpenPyXL**: Excel workbook generation for evidence packages and data analysis reports with professional formatting, styling, and charts
- **Python-DOCX**: Word document generation for formal takedown complaints and legal documentation

## Web Interface
- **Gradio**: Web-based user interface framework providing an accessible frontend for brand protection analysts and enforcement teams

## File System Operations
- **OS/JSON/Datetime**: Built-in Python libraries for file management, data serialization, and timestamp generation

## Data Format Support
The application handles multiple data formats including CSV for structured data export, Markdown for technical documentation, and Excel for business intelligence reporting. All external dependencies are managed through a requirements.txt file with pinned versions for stability.