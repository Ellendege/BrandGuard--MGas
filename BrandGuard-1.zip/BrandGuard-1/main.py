import os
import re
import json
from datetime import datetime
import pandas as pd
import gradio as gr
from ddgs import DDGS
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

# ========================
# BRANDGUARD ENTERPRISE CONFIG
# ========================
BRAND_NAME = "M-Gas Kenya"
OUTPUT_DIR = "evidence"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Ground Truth (Official Page Reference)
OFFICIAL_DATA = {
    "name": "M-Gas",
    "entity_type": "Page",
    "category": "Gas & chemical service",
    "followers": 65000,
    "domain": "mgas.ke",
    "tagline": "M-Gas is changing lives by providing pay-as-you-go cooking gas to all Kenyans.",
    "verification": False,
    "contact_buttons": ["WhatsApp", "Message"],
    "official_phone": "0792 556677"  # Only legitimate contact number
}

# Detection Logic Constants
SUSPICIOUS_SUFFIXES = ["offers", "promo", "customer care", "giveaway", "support", "agent", "refills", "hr", "careers"]
SCAMMY_ARTIFACTS = ["wa.me", "whatsapp", "paybill", "mpesa", "till"]

# ========================
# SCORING ENGINE
# ========================
def calculate_risk_score(entity):
    """
    Enhanced BrandGuard scoring algorithm with specific M-Gas impersonation rules
    Risk Thresholds: Likely Impersonator ≥12, Suspicious 8-11, Low Risk <8
    """
    score = 0
    name = entity.get("name", "")
    about = entity.get("about_snippet", "")
    url = entity.get("url", "")
    entity_type = entity.get("entity_type", "Page")
    followers = entity.get("followers_count", 0) or 0
    
    name_lower = name.lower()
    about_lower = about.lower()
    full_text = about + " " + url + " " + name
    
    # === CRITICAL IMPERSONATION RULES (INSTANT HIGH RISK) ===
    
    # Rule 1: Any Group with M-Gas/mgas name is automatically fake
    mgas_variants = ["mgas", "m-gas", "m gas"]
    if entity_type == "Group" and any(variant in name_lower for variant in mgas_variants):
        score = 16  # Maximum risk - definite impersonator
        return score, False
    
    # Rule 2: Any page/group with numbered name (mgas1, mgas2, etc.)
    if has_numbered_name_variant(name):
        score = 16  # Maximum risk - definite impersonator
        return score, False
    
    # Rule 3: Any contact number that is NOT 0792 556677
    has_fake_contacts, fake_numbers = has_fake_contact_numbers(full_text)
    if has_fake_contacts:
        score = 16  # Maximum risk - definite impersonator
        return score, False
    
    # === STANDARD SCORING (if not caught by critical rules) ===
    
    # Positive Authentic Signals
    tagline_match = OFFICIAL_DATA["tagline"].lower() in about_lower
    if tagline_match:
        score += 3
    
    if OFFICIAL_DATA["domain"] in (about_lower + " " + url.lower()):
        score += 3
    
    if 55000 <= followers <= 75000:  # Near ~65K baseline
        score += 2
    
    if entity_type == "Page":
        score += 2
    
    # Negative Signals
    if entity_type == "Group":
        score -= 4
    
    if not tagline_match:
        score -= 3
    
    if OFFICIAL_DATA["domain"] not in (about_lower + " " + url.lower()):
        score -= 3
    
    if any(suffix in name_lower for suffix in SUSPICIOUS_SUFFIXES):
        score -= 2
    
    if followers < 1000 or followers > 200000:
        score -= 2
    
    if any(artifact in (about_lower + " " + url.lower()) for artifact in SCAMMY_ARTIFACTS):
        score -= 2
    
    return max(0, min(score, 16)), tagline_match

def get_risk_label(score):
    """Convert risk score to human-readable label"""
    if score >= 12:
        return "Likely Impersonator"
    elif score >= 8:
        return "Suspicious"
    return "Low Risk/Unrelated"

def convert_to_normalized_score(risk_score):
    """Convert 0-16 risk score to 0.00-1.00 normalized score"""
    return min(1.0, max(0.0, risk_score / 16.0))

def get_professional_risk_level(normalized_score):
    """Map normalized score to professional risk levels"""
    if normalized_score >= 0.90:
        return "Critical"
    elif normalized_score >= 0.80:
        return "High"
    elif normalized_score >= 0.65:
        return "Medium"
    elif normalized_score >= 0.50:
        return "Low"
    else:
        return "Info"

def get_priority(risk_level):
    """Map risk level to priority"""
    priority_map = {
        "Critical": "P1",
        "High": "P2", 
        "Medium": "P3",
        "Low": "P4",
        "Info": "P5"
    }
    return priority_map.get(risk_level, "P5")

def extract_signals(entity):
    """Extract up to 3 key signals from entity data"""
    signals = []
    
    # Check impersonation flags
    flags = entity.get("impersonation_flags", {})
    if flags.get("fake_contacts"):
        signals.append("unauthorized contact info")
    if flags.get("numbered_name"):
        signals.append("name spoof variant")
    if flags.get("unauthorized_group"):
        signals.append("fake Facebook Group")
    
    # Check for suspicious claims
    claims = entity.get("suspicious_claims", [])
    if claims:
        if any(word in " ".join(claims).lower() for word in ["promo", "giveaway", "offer"]):
            signals.append("promo + giveaways")
        elif "official" in " ".join(claims).lower():
            signals.append("false authority claims")
    
    # Check contact handles
    handles = entity.get("contact_handles_detected", {})
    if handles.get("whatsapp"):
        signals.append("WhatsApp in bio")
    if handles.get("mpesa_paybill_or_till"):
        signals.append("payment collection")
    
    # Check tagline mismatch
    if not entity.get("tagline_match", False):
        signals.append("missing official tagline")
    
    # Return top 3 signals
    return signals[:3]

def get_confidence_level(signals):
    """Determine confidence based on number of signals"""
    signal_count = len([s for s in signals if s])
    if signal_count >= 2:
        return "High"
    elif signal_count == 1:
        return "Medium"
    else:
        return "Low"

def get_recommended_action(risk_level, confidence):
    """Determine recommended action and reason"""
    if risk_level == "Critical":
        return "Takedown", "definitive impersonation"
    elif risk_level == "High":
        return "Takedown", "probable fraud attempt"
    elif risk_level == "Medium" and confidence == "High":
        return "Monitor", "suspicious indicators present"
    elif risk_level == "Medium":
        return "Monitor", "potential risk identified"
    else:
        return "Ignore", "minimal threat level"

def get_compliance_flags(entity):
    """Extract compliance flags from entity"""
    flags = entity.get("impersonation_flags", {})
    if flags.get("fake_contacts") or flags.get("numbered_name"):
        return "Potential IP misuse"
    elif entity.get("suspicious_claims"):
        return "Misleading branding"
    else:
        return "—"

# ========================
# DATA EXTRACTION & ANALYSIS
# ========================
def extract_contact_handles(text):
    """Extract contact information from text"""
    handles = {
        "phones": re.findall(r'(?:\+254|0)\d{9}', text),  # Enhanced to catch 0792 format
        "emails": re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text),
        "whatsapp": re.findall(r'wa\.me/[^\s]+', text),
        "mpesa_paybill_or_till": re.findall(r'(?:paybill|till)\s*:?\s*\d+', text, re.IGNORECASE)
    }
    return handles

def has_fake_contact_numbers(text):
    """Check if text contains phone numbers that are NOT the official M-Gas number"""
    official_number = OFFICIAL_DATA["official_phone"].replace(" ", "")  # "0792556677"
    
    # Find all phone numbers in various formats
    phone_patterns = [
        r'0\d{9}',           # 0792556677
        r'\+254\d{9}',       # +254792556677  
        r'0\d{3}\s\d{6}',    # 0792 556677
        r'\+254\s\d{3}\s\d{6}' # +254 792 556677
    ]
    
    found_numbers = []
    for pattern in phone_patterns:
        matches = re.findall(pattern, text)
        for match in matches:
            # Normalize the number (remove spaces, convert +254 to 0)
            normalized = match.replace(" ", "").replace("+254", "0")
            found_numbers.append(normalized)
    
    # Check if any found number is NOT the official number
    fake_numbers = [num for num in found_numbers if num != official_number]
    return len(fake_numbers) > 0, fake_numbers

def has_numbered_name_variant(name):
    """Check if name has suspicious number after mgas (e.g., mgas1, mgas2, etc.)"""
    # Check for patterns like: mgas1, mgas 2, M-Gas3, etc.
    patterns = [
        r'mgas\s*\d+',
        r'm-gas\s*\d+',
        r'm\s*gas\s*\d+'
    ]
    
    name_lower = name.lower()
    for pattern in patterns:
        if re.search(pattern, name_lower):
            return True
    return False

def detect_suspicious_claims(text):
    """Detect suspicious claims in entity descriptions"""
    suspicious_terms = ["official", "promo", "agent", "authorized", "verified", "customer care", "support"]
    return [term for term in suspicious_terms if term in text.lower()]

def create_entity_record(raw_data, found_via="DDGS"):
    """Transform raw search data into standardized entity record"""
    name = raw_data.get("title", "")
    url = raw_data.get("href", "")
    snippet = raw_data.get("body", "")
    
    # Determine entity type
    entity_type = "Group" if "/groups/" in url else "Page"
    
    # Extract followers (this would require additional API calls in real implementation)
    followers_count = None  # Placeholder - would need Page Insights API
    
    # Calculate risk score with enhanced detection
    temp_entity = {
        "name": name,
        "about_snippet": snippet,
        "url": url,
        "entity_type": entity_type,
        "followers_count": followers_count
    }
    risk_score, tagline_match = calculate_risk_score(temp_entity)
    
    # Check for specific impersonation indicators
    has_fake_contacts, fake_contact_list = has_fake_contact_numbers(snippet + " " + name)
    numbered_name = has_numbered_name_variant(name)
    
    # Build complete entity record
    entity = {
        "entity_type": entity_type,
        "name": name,
        "url": url,
        "username_or_id": url.split('/')[-1] if url else "",
        "risk_score": risk_score,
        "risk_label": get_risk_label(risk_score),
        "tagline_match": tagline_match,
        "category": "",  # Would require Graph API
        "about_snippet": snippet[:200],
        "followers_count": followers_count,
        "members_count": None,
        "creation_date": None,  # Would require Page Transparency
        "primary_country": None,  # Would require Page Transparency
        "found_via": found_via,
        "recent_post_examples": [],  # Would require Posts API
        "contact_handles_detected": extract_contact_handles(snippet),
        "suspicious_claims": detect_suspicious_claims(snippet),
        "fake_contact_numbers": fake_contact_list if has_fake_contacts else [],
        "has_numbered_name": numbered_name,
        "screenshot_paths": [],  # Manual collection required
        "notes": f"Auto-detected via {found_via} search",
        "compliance_note": "Public data only - no ToS violations",
        "impersonation_flags": {
            "fake_contacts": has_fake_contacts,
            "numbered_name": numbered_name,
            "unauthorized_group": entity_type == "Group" and any(v in name.lower() for v in ["mgas", "m-gas", "m gas"])
        }
    }
    
    return entity

# ========================
# OSINT DISCOVERY ENGINE
# ========================
def discover_impersonators(brand_terms, max_results=20):
    """
    OSINT discovery using compliant public search
    Strictly adheres to Meta ToS - no scraping or login circumvention
    """
    entities = []
    search_terms = [
        "promo", "offers", "giveaway", "customer care", 
        "support", "refills", "agent", "hr", "careers"
    ]
    
    try:
        with DDGS() as ddg:
            for brand in brand_terms:
                for term in search_terms:
                    query = f'site:facebook.com "{brand}" "{term}"'
                    
                    try:
                        results = ddg.text(query, max_results=max_results//len(search_terms))
                        for result in results:
                            if "facebook.com" in result.get("href", ""):
                                entity = create_entity_record(result, "DDGS")
                                entities.append(entity)
                    except Exception as e:
                        print(f"Search error for '{query}': {e}")
                        
    except Exception as e:
        print(f"Discovery engine error: {e}")
    
    return entities

# ========================
# REPORT GENERATION
# ========================
def generate_evidence_workbook(entities):
    """Generate professional evidence workbook in Excel format"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = os.path.join(OUTPUT_DIR, f"evidence_workbook_{timestamp}.xlsx")
    
    # Create workbook and worksheet
    wb = Workbook()
    ws = wb.active
    ws.title = "Brand Protection Evidence"
    
    # Define styles
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
    high_risk_fill = PatternFill(start_color="FFE6E6", end_color="FFE6E6", fill_type="solid")
    medium_risk_fill = PatternFill(start_color="FFF2E6", end_color="FFF2E6", fill_type="solid")
    low_risk_fill = PatternFill(start_color="E6F3E6", end_color="E6F3E6", fill_type="solid")
    
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'), 
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Headers
    headers = [
        "Entity Name", "Platform", "Type", "URL", "Risk Score", "Risk Level",
        "Official Tagline", "Description", "Followers", "Contact Info", 
        "Suspicious Activity", "Discovery Method", "Analysis Notes", "Compliance Status"
    ]
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = border
    
    # Data rows with conditional formatting
    for row_idx, entity in enumerate(entities, 2):
        # Determine row color based on risk
        if entity["risk_score"] >= 12:
            row_fill = high_risk_fill
        elif entity["risk_score"] >= 8:
            row_fill = medium_risk_fill
        else:
            row_fill = low_risk_fill
        
        data = [
            entity["name"],
            "Facebook",
            entity["entity_type"],
            entity["url"],
            entity["risk_score"],
            entity["risk_label"],
            "✅ Present" if entity["tagline_match"] else "❌ Missing",
            entity["about_snippet"][:100] + "..." if len(entity["about_snippet"]) > 100 else entity["about_snippet"],
            entity.get("followers_count", "Unknown"),
            ", ".join([f"{k}: {v}" for k, v in entity["contact_handles_detected"].items() if v]),
            "; ".join(entity["suspicious_claims"]) if entity["suspicious_claims"] else "None detected",
            entity["found_via"],
            f"Risk factors: {len(entity.get('impersonation_flags', {}))} critical flags",
            "ToS Compliant"
        ]
        
        for col, value in enumerate(data, 1):
            cell = ws.cell(row=row_idx, column=col, value=value)
            cell.fill = row_fill
            cell.border = border
            cell.alignment = Alignment(wrap_text=True, vertical='top')
    
    # Auto-adjust column widths
    for col in range(1, len(headers) + 1):
        column_letter = get_column_letter(col)
        ws.column_dimensions[column_letter].width = 15
        
    # Special width adjustments
    ws.column_dimensions['A'].width = 25  # Entity Name
    ws.column_dimensions['D'].width = 40  # URL
    ws.column_dimensions['H'].width = 30  # Description
    
    # Add summary sheet
    summary_ws = wb.create_sheet("Executive Summary")
    summary_ws.append(["M-Gas Kenya - Brand Protection Evidence Summary"])
    summary_ws.append([f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"])
    summary_ws.append([""])
    summary_ws.append(["Risk Distribution:"])
    summary_ws.append([f"High Risk (≥12): {len([e for e in entities if e['risk_score'] >= 12])}"])
    summary_ws.append([f"Medium Risk (8-11): {len([e for e in entities if 8 <= e['risk_score'] < 12])}"])
    summary_ws.append([f"Low Risk (<8): {len([e for e in entities if e['risk_score'] < 8])}"])
    summary_ws.append([f"Total Entities: {len(entities)}"])
    
    # Style summary sheet
    for row in summary_ws.iter_rows():
        for cell in row:
            cell.font = Font(size=12)
            if cell.row == 1:
                cell.font = Font(size=16, bold=True)
    
    wb.save(filepath)
    return filepath

def generate_takedown_complaint(entities):
    """Generate professional takedown complaint in Word format"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = os.path.join(OUTPUT_DIR, f"takedown_complaint_{timestamp}.docx")
    
    # Filter high-risk entities
    flagged = [e for e in entities if e["risk_score"] >= 12]
    
    # Create Word document
    doc = Document()
    
    # Document title
    title = doc.add_heading('Brand Protection Takedown Request', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    subtitle = doc.add_heading('M-Gas Kenya Intellectual Property Violation Report', level=2)
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Document info
    doc.add_paragraph(f"Submission Date: {datetime.now().strftime('%B %d, %Y')}")
    doc.add_paragraph("Complainant: M-Gas Kenya")
    doc.add_paragraph("Report Type: Brand Impersonation & Trademark Violation")
    doc.add_paragraph("")
    
    # Executive Summary
    doc.add_heading('Executive Summary', level=1)
    summary_p = doc.add_paragraph(
        f"This document presents evidence of {len(flagged)} entities engaging in brand impersonation "
        f"and potential trademark violations against M-Gas Kenya's intellectual property. These violations "
        f"pose significant risks to customer trust, brand reputation, and business operations."
    )
    
    # Legal Basis
    doc.add_heading('Legal Basis', level=1)
    legal_list = doc.add_paragraph()
    legal_list.add_run('• Trademark Infringement: ').bold = True
    legal_list.add_run('Unauthorized use of M-Gas branding and identity\n')
    legal_list.add_run('• Impersonation: ').bold = True
    legal_list.add_run('False representation as official M-Gas presence\n')
    legal_list.add_run('• Consumer Deception: ').bold = True
    legal_list.add_run('Misleading customers about official services\n')
    legal_list.add_run('• Platform Violation: ').bold = True
    legal_list.add_run('Facebook Community Standards breach')
    
    # Official Brand Reference
    doc.add_heading('Official Brand Reference', level=1)
    ref_table = doc.add_table(rows=6, cols=2)
    ref_table.style = 'Table Grid'
    
    ref_data = [
        ('Page Name', OFFICIAL_DATA["name"]),
        ('Entity Type', OFFICIAL_DATA["entity_type"]),
        ('Official Domain', OFFICIAL_DATA["domain"]),
        ('Official Tagline', OFFICIAL_DATA["tagline"]),
        ('Legitimate Contact', OFFICIAL_DATA["official_phone"]),
        ('Approximate Followers', f"~{OFFICIAL_DATA['followers']:,}")
    ]
    
    for i, (label, value) in enumerate(ref_data):
        ref_table.cell(i, 0).text = label
        ref_table.cell(i, 0).paragraphs[0].runs[0].bold = True
        ref_table.cell(i, 1).text = str(value)
    
    # Violating Entities
    doc.add_heading(f'Violating Entities ({len(flagged)} Flagged for Takedown)', level=1)
    
    if not flagged:
        doc.add_paragraph("No high-risk entities detected requiring immediate takedown action.")
    else:
        for i, entity in enumerate(flagged, 1):
            # Entity header
            entity_heading = doc.add_heading(f'{i}. {entity["name"]}', level=2)
            
            # Entity details table
            entity_table = doc.add_table(rows=8, cols=2)
            entity_table.style = 'Table Grid'
            
            # Determine impersonation flags
            flags = entity.get("impersonation_flags", {})
            violation_details = []
            if flags.get("fake_contacts"):
                violation_details.append("Unauthorized contact information")
            if flags.get("numbered_name"):
                violation_details.append("Name variant spoofing")
            if flags.get("unauthorized_group"):
                violation_details.append("Fake Facebook Group")
            
            entity_data = [
                ('Platform URL', entity["url"]),
                ('Entity Type', f"Facebook {entity['entity_type']}"),
                ('Risk Assessment', f"{entity['risk_score']}/16 ({entity['risk_label']})"),
                ('Official Tagline Present', '✅ Yes' if entity['tagline_match'] else '❌ No'),
                ('Violation Indicators', ', '.join(violation_details) if violation_details else 'General impersonation'),
                ('Contact Information', ', '.join([f"{k}: {v}" for k, v in entity['contact_handles_detected'].items() if v]) or 'None detected'),
                ('Suspicious Claims', '; '.join(entity['suspicious_claims']) if entity['suspicious_claims'] else 'None detected'),
                ('Evidence Method', 'Public OSINT analysis, ToS compliant')
            ]
            
            for j, (label, value) in enumerate(entity_data):
                entity_table.cell(j, 0).text = label
                entity_table.cell(j, 0).paragraphs[0].runs[0].bold = True
                entity_table.cell(j, 1).text = str(value)
            
            doc.add_paragraph("")  # Spacing
    
    # Footer
    doc.add_paragraph("")
    doc.add_heading('Compliance Statement', level=1)
    compliance_p = doc.add_paragraph(
        "All evidence was collected through public interfaces in compliance with Meta's Terms of Service. "
        "No unauthorized access or data scraping was performed. This report is submitted in good faith "
        "for the protection of intellectual property rights and consumer safety."
    )
    
    # Save document
    doc.save(filepath)
    return filepath

def generate_threat_intel_brief(entities):
    """Generate professional threat intelligence brief using standardized format"""
    from datetime import datetime, timezone
    
    # Convert entities to professional format
    professional_entities = []
    for entity in entities:
        normalized_score = convert_to_normalized_score(entity["risk_score"])
        risk_level = get_professional_risk_level(normalized_score)
        priority = get_priority(risk_level)
        signals = extract_signals(entity)
        confidence = get_confidence_level(signals)
        action, reason = get_recommended_action(risk_level, confidence)
        compliance_flags = get_compliance_flags(entity)
        
        professional_entities.append({
            **entity,
            "normalized_score": normalized_score,
            "professional_risk_level": risk_level,
            "priority": priority,
            "signals": signals,
            "confidence": confidence,
            "recommended_action": action,
            "action_reason": reason,
            "compliance_flags": compliance_flags
        })
    
    # Count by professional risk levels
    critical_count = len([e for e in professional_entities if e["professional_risk_level"] == "Critical"])
    high_count = len([e for e in professional_entities if e["professional_risk_level"] == "High"])
    medium_count = len([e for e in professional_entities if e["professional_risk_level"] == "Medium"])
    low_count = len([e for e in professional_entities if e["professional_risk_level"] == "Low"])
    
    # Sort by priority then score
    priority_order = {"P1": 1, "P2": 2, "P3": 3, "P4": 4, "P5": 5}
    sorted_entities = sorted(professional_entities, key=lambda x: (priority_order[x["priority"]], -x["normalized_score"]))
    
    # Generate timestamps and scan terms
    utc_timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    scan_terms = "M-Gas | M Gas | M-Gas Kenya | mgas ke | mgas kenya"
    
    # Get top 3 risks
    top_3_risks = []
    for entity in sorted_entities[:3]:
        top_3_risks.append(f"{entity['name']} — Facebook {entity['entity_type']} — {entity['professional_risk_level']} — {entity['url']}")
    
    # Generate immediate actions
    actions = []
    if critical_count > 0:
        actions.append(f"Submit takedown requests for {critical_count} critical threats — **Owner:** Legal")
    if high_count > 0:
        actions.append(f"Issue customer fraud alerts about {high_count} high-risk accounts — **Owner:** Comms")
    if critical_count + high_count > 0:
        actions.append(f"Brief customer service teams on {critical_count + high_count} active threats — **Owner:** Fraud Ops")
    
    # Generate filenames
    timestamp_str = datetime.now().strftime('%Y%m%d_%H%M%S')
    csv_filename = f"evidence_workbook_{timestamp_str}.csv"
    takedown_filename = f"takedown_complaint_{timestamp_str}.md"
    intel_filename = f"threat_intelligence_brief_{timestamp_str}.md"
    
    content = f"""## Key Business Intelligence
- **Timeframe:** {utc_timestamp}
- **Scan Terms:** `{scan_terms}`
- **Findings Summary:** Total {len(entities)} suspects | Critical {critical_count} | High {high_count} | Medium {medium_count} | Low {low_count}
- **Top 3 Risks (one line each):**"""
    
    for i, risk in enumerate(top_3_risks, 1):
        content += f"\n  {i}) {risk}"
    
    if len(top_3_risks) < 3:
        for i in range(len(top_3_risks) + 1, 4):
            content += f"\n  {i}) — — — —"
    
    content += f"""\n- **Generated Files:**
  - Evidence CSV: {csv_filename}
  - Takedown Letter: {takedown_filename}
  - Intel Brief: {intel_filename}
- **Immediate Actions (max 3, imperative, with owner):**"""
    
    for i, action in enumerate(actions[:3], 1):
        content += f"\n  {i}) {action}"
    
    content += "\n\n## Individual Threat Assessments"
    
    if not sorted_entities:
        content += "\n0 suspects"
    else:
        for entity in sorted_entities:
            signals_text = " • ".join(entity["signals"]) if entity["signals"] else "—"
            followers = entity.get("followers_count", "—")
            if followers == "—" or followers is None:
                followers = "—"
            
            content += f"""\n\n### {entity["name"]}  —  **Facebook {entity["entity_type"]}**  —  **{entity["professional_risk_level"]}** (Score: {entity["normalized_score"]:.2f})  —  **Priority {entity["priority"]}**
- **URL:** {entity["url"]}
- **Followers:** {followers}   |   **Created:** —
- **Signals (max 3):** • {signals_text}
- **Confidence:** {entity["confidence"]}
- **Recommended Action:** {entity["recommended_action"]}  (Reason: {entity["action_reason"]})
- **Compliance Flags:** {entity["compliance_flags"]}
- **Notes (≤20 words):** Auto-detected via OSINT scan using public data only."""
    
    # Save to file
    filepath = os.path.join(OUTPUT_DIR, intel_filename)
    
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    
    return filepath

def generate_individual_threat_report(professional_entities):
    """Generate detailed individual threat assessment report in Word format"""
    from datetime import datetime, timezone
    
    # Generate filename
    timestamp_str = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"individual_threat_assessment_{timestamp_str}.docx"
    filepath = os.path.join(OUTPUT_DIR, filename)
    
    # Create Word document
    doc = Document()
    
    # Document title and header
    title = doc.add_heading('Individual Threat Assessment Report', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Document metadata
    utc_timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    
    doc.add_paragraph(f"Generated: {utc_timestamp}")
    doc.add_paragraph("Analyst: BrandGuard Enterprise OSINT System")
    doc.add_paragraph("Brand: M-Gas Kenya")
    doc.add_paragraph("")
    
    # Assessment Overview
    doc.add_heading('Assessment Overview', level=1)
    overview_p = doc.add_paragraph(
        "This report provides detailed analysis of each detected threat against M-Gas Kenya's digital presence, "
        "with prioritized risk assessments and actionable recommendations for enforcement teams."
    )
    
    doc.add_paragraph(f"Total Entities Analyzed: {len(professional_entities)}")
    doc.add_paragraph("Assessment Methodology: Automated OSINT + Professional Risk Scoring")
    doc.add_paragraph("Compliance: Meta ToS compliant public data analysis")
    doc.add_paragraph("")
    
    # Sort by priority then score
    priority_order = {"P1": 1, "P2": 2, "P3": 3, "P4": 4, "P5": 5}
    sorted_entities = sorted(professional_entities, key=lambda x: (priority_order[x["priority"]], -x["normalized_score"]))
    
    if not sorted_entities:
        doc.add_heading('Assessment Result', level=1)
        doc.add_paragraph("Status: No threats detected during scan period")
        doc.add_paragraph("Recommendation: Continue regular monitoring")
    else:
        doc.add_heading('Individual Threat Profiles', level=1)
        
        for i, entity in enumerate(sorted_entities, 1):
            signals_text = " • ".join(entity["signals"]) if entity["signals"] else "No specific signals detected"
            followers = entity.get("followers_count", "—")
            if followers == "—" or followers is None:
                followers = "Unknown"
            
            # Add threat profile heading
            threat_heading = doc.add_heading(f'Threat Profile #{i}: {entity["name"]}', level=2)
            
            # Create profile table
            profile_table = doc.add_table(rows=12, cols=2)
            profile_table.style = 'Table Grid'
            
            # Profile data
            profile_data = [
                ('Platform', f"Facebook {entity['entity_type']}"),
                ('URL', entity["url"]),
                ('Followers', str(followers)),
                ('Discovery Method', 'OSINT search via public API'),
                ('Risk Level', f"{entity['professional_risk_level']} (Score: {entity['normalized_score']:.2f}/1.00)"),
                ('Priority', f"{entity['priority']} (Business criticality ranking)"),
                ('Confidence', f"{entity['confidence']} (Assessment reliability)"),
                ('Detected Signals', signals_text),
                ('Tagline Analysis', '✅ Official tagline present' if entity.get("tagline_match") else '❌ Official tagline missing/altered'),
                ('Contact Analysis', '⚠️ Unauthorized contact information detected' if entity.get("impersonation_flags", {}).get("fake_contacts") else '✅ No unauthorized contacts detected'),
                ('Recommended Action', f"{entity['recommended_action']} ({entity['action_reason'].title()})"),
                ('Compliance Concerns', entity['compliance_flags'])
            ]
            
            for j, (label, value) in enumerate(profile_data):
                profile_table.cell(j, 0).text = label
                profile_table.cell(j, 0).paragraphs[0].runs[0].bold = True
                profile_table.cell(j, 1).text = str(value)
            
            doc.add_paragraph("")  # Spacing between profiles
    
    # Summary & Next Steps
    doc.add_heading('Summary & Next Steps', level=1)
    
    summary_data = [
        f"Assessment Complete: {utc_timestamp}",
        f"Total Analyzed: {len(professional_entities)} entities",
        f"Enforcement Ready: {len([e for e in sorted_entities if e['priority'] in ['P1', 'P2']])} high-priority cases"
    ]
    
    for item in summary_data:
        doc.add_paragraph(item)
    
    doc.add_paragraph("")
    doc.add_paragraph("Recommended Actions:").runs[0].bold = True
    actions_list = doc.add_paragraph()
    actions_list.add_run("1. Legal Team: ").bold = True
    actions_list.add_run("Review P1/P2 priority cases for takedown requests\n")
    actions_list.add_run("2. Communications: ").bold = True
    actions_list.add_run("Prepare customer advisories if fraud indicators present\n")
    actions_list.add_run("3. Monitoring: ").bold = True
    actions_list.add_run("Continue surveillance for new impersonation attempts")
    
    doc.add_paragraph("")
    doc.add_paragraph("Report Distribution:").runs[0].bold = True
    dist_list = doc.add_paragraph()
    dist_list.add_run("• Legal Counsel (for enforcement decisions)\n")
    dist_list.add_run("• Brand Protection Team (for strategic planning)\n")
    dist_list.add_run("• Customer Support (for fraud awareness)")
    
    doc.add_paragraph("")
    confidential = doc.add_paragraph("This report contains confidential business intelligence. Distribution restricted to authorized personnel.")
    confidential.runs[0].italic = True
    
    # Save document
    doc.save(filepath)
    return filepath

# ========================
# GRADIO INTERFACE
# ========================
def run_brandguard_scan(brand_terms, search_intensity):
    """Main BrandGuard scanning function"""
    if not brand_terms.strip():
        # Return error with empty cards
        empty_card = """
<div class="risk-card">
<span class="risk-icon">❌</span>
<h3>Error</h3>
<div style="font-size: 1rem; color: #ef4444;">Input Required</div>
<small>Please enter brand terms</small>
</div>
"""
        return ("❌ Error: Please enter brand terms to scan", "", "", 
                empty_card, empty_card, empty_card, empty_card)
    
    # Parse brand terms
    terms = [term.strip() for term in brand_terms.split(",") if term.strip()]
    
    # OSINT Discovery
    status_msg = f"🔍 **BrandGuard Enterprise Scan Initiated**\n\n"
    status_msg += f"**Target Brand:** {BRAND_NAME}\n"
    status_msg += f"**Search Terms:** {', '.join(terms)}\n"
    status_msg += f"**Intensity:** {int(search_intensity)} results per term\n"
    status_msg += f"**Compliance:** Meta ToS compliant (public data only)\n\n"
    status_msg += "⏳ Discovering entities..."
    
    try:
        entities = discover_impersonators(terms, int(search_intensity))
        
        if not entities:
            # Return zero cards for no results
            zero_card_high = """
<div class="risk-card risk-high">
<span class="risk-icon">🚨</span>
<h3>Critical Threats</h3>
<div style="font-size: 2rem; font-weight: bold; color: #ef4444;">0</div>
<small>No immediate threats</small>
</div>
"""
            
            zero_card_medium = """
<div class="risk-card risk-medium">
<span class="risk-icon">⚠️</span>
<h3>Suspicious Activity</h3>
<div style="font-size: 2rem; font-weight: bold; color: #f59e0b;">0</div>
<small>No suspicious activity</small>
</div>
"""
            
            zero_card_low = """
<div class="risk-card risk-low">
<span class="risk-icon">ℹ️</span>
<h3>Low Priority</h3>
<div style="font-size: 2rem; font-weight: bold; color: #10b981;">0</div>
<small>No low priority items</small>
</div>
"""
            
            zero_card_total = """
<div class="risk-card risk-total">
<span class="risk-icon">📊</span>
<h3>Total Detected</h3>
<div style="font-size: 2rem; font-weight: bold; color: #3b82f6;">0</div>
<small>No brand mentions found</small>
</div>
"""
            
            no_threats_status = """✅ **Scan Complete - No Threats Detected**

## 🛡️ **Security Status: ALL CLEAR**
No suspicious entities found using your brand monitoring terms.

## 📄 **Generated Reports**
- **Evidence Workbook:** Empty dataset (no entities to document)
- **Takedown Requests:** None required (no violations detected)
- **Threat Assessment:** Clean scan results documented
- **Individual Analysis:** No threat profiles to generate

## 📊 **Protection Value**
• **Brand Safety Status:** Secure from impersonation threats
• **Customer Protection:** No fraudulent accounts detected
• **Monitoring Recommendation:** Continue regular surveillance

**Scan Result:** Your digital brand presence appears protected.
"""
            
            return (status_msg + "\n\n✅ **Scan Complete** - No suspicious entities detected", "", no_threats_status,
                    zero_card_high, zero_card_medium, zero_card_low, zero_card_total)
        
        # Risk Analysis
        high_risk = [e for e in entities if e["risk_score"] >= 12]
        medium_risk = [e for e in entities if 8 <= e["risk_score"] < 12]
        low_risk = [e for e in entities if e["risk_score"] < 8]
        
        # Convert entities to professional format for enhanced reporting
        professional_entities = []
        for entity in entities:
            normalized_score = convert_to_normalized_score(entity["risk_score"])
            risk_level = get_professional_risk_level(normalized_score)
            priority = get_priority(risk_level)
            signals = extract_signals(entity)
            confidence = get_confidence_level(signals)
            action, reason = get_recommended_action(risk_level, confidence)
            compliance_flags = get_compliance_flags(entity)
            
            professional_entities.append({
                **entity,
                "normalized_score": normalized_score,
                "professional_risk_level": risk_level,
                "priority": priority,
                "signals": signals,
                "confidence": confidence,
                "recommended_action": action,
                "action_reason": reason,
                "compliance_flags": compliance_flags
            })
        
        # Generate Reports
        workbook_path = generate_evidence_workbook(entities)
        complaint_path = generate_takedown_complaint(entities)
        intel_path = generate_threat_intel_brief(entities)
        individual_report_path = generate_individual_threat_report(professional_entities)
        
        # Executive Summary Report
        total_threats = len(high_risk) + len(medium_risk)
        protection_value = f"${total_threats * 50000:,}" if total_threats > 0 else "$0"
        
        summary = f"""🛡️ **Brand Protection Executive Summary**

## 📊 **Business Impact Dashboard**
- 🚨 **Critical Threats Detected:** {len(high_risk)} (require immediate action)
- ⚠️ **Potential Risks:** {len(medium_risk)} (monitoring recommended)  
- ✅ **Low Priority Issues:** {len(low_risk)}
- 📈 **Total Brand Mentions:** {len(entities)}

## 💼 **Financial Protection Value**
- **Estimated Risk Prevented:** {protection_value}
- **Customer Trust Protection:** High priority threats blocked
- **Legal Preparedness:** Documentation ready for enforcement

## 📋 **Professional Documentation Generated**
- **Evidence Package:** {os.path.basename(workbook_path)}
- **Legal Takedown Request:** {os.path.basename(complaint_path)}
- **Executive Intelligence Brief:** {os.path.basename(intel_path)}

## 🎯 **Immediate Business Actions Required**
1. **Review Critical Threats** - Legal team assessment needed
2. **Customer Communications** - Proactive fraud warnings  
3. **Platform Reporting** - Submit takedown requests
4. **Internal Security** - Brief customer service teams
"""

        # Detailed Risk Assessment
        results_detail = "## 📋 **Individual Threat Analysis**\n\n"
        
        for entity in sorted(entities, key=lambda x: x["risk_score"], reverse=True):
            if entity["risk_score"] >= 12:
                risk_emoji, priority = "🚨", "CRITICAL"
                business_impact = "Immediate legal action required"
            elif entity["risk_score"] >= 8:
                risk_emoji, priority = "⚠️", "HIGH"  
                business_impact = "Enhanced monitoring recommended"
            else:
                risk_emoji, priority = "ℹ️", "LOW"
                business_impact = "Minimal business risk"
            
            # Enhanced impersonation flags
            flags = entity.get("impersonation_flags", {})
            warning_flags = []
            if flags.get("fake_contacts"):
                warning_flags.append("⚠️ Unauthorized contact information")
            if flags.get("numbered_name"):
                warning_flags.append("⚠️ Suspicious name variant")
            if flags.get("unauthorized_group"):
                warning_flags.append("⚠️ Fake Facebook Group")
            
            flags_text = "\n".join(warning_flags) if warning_flags else "No critical flags detected"
            
            results_detail += f"""### {risk_emoji} **{entity["name"]}** - {priority} PRIORITY
**Business Risk Level:** {entity["risk_score"]}/16 ({entity["risk_label"]})  
**Platform:** Facebook {entity["entity_type"]}  
**Public URL:** {entity["url"]}  
**Business Impact:** {business_impact}  
**Official Tagline Present:** {'✅ Authentic' if entity["tagline_match"] else '❌ Missing/Different'}  
**About Description:** {entity["about_snippet"][:200]}...  
**Risk Indicators:** {flags_text}  
**Suspicious Activity:** {', '.join(entity["suspicious_claims"]) if entity["suspicious_claims"] else 'None detected'}

---
"""
        
        # Create updated risk card displays
        high_risk_card = f"""
<div class="risk-card risk-high">
<span class="risk-icon">🚨</span>
<h3>Critical Threats</h3>
<div style="font-size: 2rem; font-weight: bold; color: #ef4444;">{len(high_risk)}</div>
<small>Immediate action required</small>
</div>
"""
        
        medium_risk_card = f"""
<div class="risk-card risk-medium">
<span class="risk-icon">⚠️</span>
<h3>Suspicious Activity</h3>
<div style="font-size: 2rem; font-weight: bold; color: #f59e0b;">{len(medium_risk)}</div>
<small>Enhanced monitoring</small>
</div>
"""
        
        low_risk_card = f"""
<div class="risk-card risk-low">
<span class="risk-icon">ℹ️</span>
<h3>Low Priority</h3>
<div style="font-size: 2rem; font-weight: bold; color: #10b981;">{len(low_risk)}</div>
<small>Minimal business risk</small>
</div>
"""
        
        total_card = f"""
<div class="risk-card risk-total">
<span class="risk-icon">📊</span>
<h3>Total Detected</h3>
<div style="font-size: 2rem; font-weight: bold; color: #3b82f6;">{len(entities)}</div>
<small>Brand mentions found</small>
</div>
"""
        
        # Enhanced status message with report details
        status_message = f"""✅ **Professional Reports Generated Successfully**

## 📄 **Evidence Workbook (CSV)**
`{os.path.basename(workbook_path)}`
• Structured data for {len(entities)} entities
• Risk scores, contact details, evidence links
• Ready for legal team analysis

## ⚖️ **Takedown Complaint Package (MD)**
`{os.path.basename(complaint_path)}`
• Legal documentation for {len([e for e in entities if e["risk_score"] >= 12])} high-risk entities
• Meta-compliant takedown requests
• Evidence references and violation details

## 📈 **Executive Intelligence Brief (MD)**
`{os.path.basename(intel_path)}`
• Professional threat analysis with normalized scoring
• Priority classifications and business actions
• Decision-grade intelligence for leadership

## 🎯 **Individual Threat Assessment Report (MD)**
`{os.path.basename(individual_report_path)}`
• Detailed analysis of each detected threat
• Risk profiles with actionable recommendations
• Legal and enforcement considerations

**Storage Location:** `{OUTPUT_DIR}/`
**Report Status:** All {len(professional_entities)} entities analyzed and documented
"""
        
        return (summary, results_detail, status_message, 
                high_risk_card, medium_risk_card, low_risk_card, total_card)
        
    except Exception as e:
        error_msg = f"❌ **Scan Error:** {str(e)}\n\nPlease check network connectivity and try again."
        # Return empty cards on error
        empty_card_high = """
<div class="risk-card risk-high">
<span class="risk-icon">🚨</span>
<h3>Critical Threats</h3>
<div style="font-size: 2rem; font-weight: bold; color: #ef4444;">-</div>
<small>Immediate action required</small>
</div>
"""
        
        empty_card_medium = """
<div class="risk-card risk-medium">
<span class="risk-icon">⚠️</span>
<h3>Suspicious Activity</h3>
<div style="font-size: 2rem; font-weight: bold; color: #f59e0b;">-</div>
<small>Enhanced monitoring</small>
</div>
"""
        
        empty_card_low = """
<div class="risk-card risk-low">
<span class="risk-icon">ℹ️</span>
<h3>Low Priority</h3>
<div style="font-size: 2rem; font-weight: bold; color: #10b981;">-</div>
<small>Minimal business risk</small>
</div>
"""
        
        empty_card_total = """
<div class="risk-card risk-total">
<span class="risk-icon">📊</span>
<h3>Total Detected</h3>
<div style="font-size: 2rem; font-weight: bold; color: #3b82f6;">-</div>
<small>Brand mentions found</small>
</div>
"""
        
        error_status = f"""❌ **Scan Error Encountered**

{error_msg}

## 🔍 **Troubleshooting Guide**
1. **Network Connectivity:** Verify internet connection is stable
2. **Search Terms:** Ensure brand terms are properly formatted
3. **Search Intensity:** Try reducing scan depth (10-15 range)
4. **Service Status:** Check if search APIs are operational

## 📄 **Report Status**
• **Evidence Collection:** Failed due to scan error
• **Threat Analysis:** Unable to complete assessment
• **Documentation:** No reports generated
• **Next Steps:** Resolve connectivity and retry scan

**Resolution:** Contact technical support if errors persist.
"""
        
        return (status_msg + f"\n\n{error_msg}", "", error_status, 
                empty_card_high, empty_card_medium, empty_card_low, empty_card_total)

# ========================
# ENTERPRISE UI
# ========================
with gr.Blocks(
    title="BrandGuard Enterprise",
    theme=gr.themes.Soft(),
    css="""
    /* Dark Mode Dashboard Theme */
    .gradio-container {
        background: linear-gradient(135deg, #0f0f23 0%, #1a1a2e 50%, #16213e 100%) !important;
        font-family: 'Inter', 'Segoe UI', system-ui, sans-serif !important;
        color: #e2e8f0 !important;
        min-height: 100vh;
    }
    
    /* Typography Hierarchy */
    h1 { font-size: 2.5rem !important; font-weight: 800 !important; color: #ffffff !important; }
    h2 { font-size: 1.8rem !important; font-weight: 700 !important; color: #f1f5f9 !important; }
    h3 { font-size: 1.3rem !important; font-weight: 600 !important; color: #cbd5e1 !important; }
    
    /* Card-based Layout */
    .dashboard-card {
        background: rgba(30, 41, 59, 0.8) !important;
        border: 1px solid rgba(148, 163, 184, 0.2) !important;
        border-radius: 16px !important;
        padding: 24px !important;
        margin: 16px 0 !important;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3) !important;
        backdrop-filter: blur(10px) !important;
        transition: all 0.3s ease !important;
    }
    
    .dashboard-card:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4) !important;
    }
    
    /* Risk Status Cards */
    .risk-card {
        background: linear-gradient(135deg, rgba(30, 41, 59, 0.9), rgba(51, 65, 85, 0.6)) !important;
        border-radius: 12px !important;
        padding: 20px !important;
        margin: 12px !important;
        text-align: center !important;
        transition: all 0.3s ease !important;
        border: 1px solid rgba(148, 163, 184, 0.3) !important;
    }
    
    .risk-high {
        border-left: 4px solid #ef4444 !important;
        background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.05)) !important;
    }
    
    .risk-medium {
        border-left: 4px solid #f59e0b !important;
        background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(217, 119, 6, 0.05)) !important;
    }
    
    .risk-low {
        border-left: 4px solid #10b981 !important;
        background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.05)) !important;
    }
    
    .risk-total {
        border-left: 4px solid #3b82f6 !important;
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(37, 99, 235, 0.05)) !important;
    }
    
    /* Buttons with Accent Colors */
    .gr-button-primary {
        background: linear-gradient(45deg, #6366f1, #8b5cf6) !important;
        border: none !important;
        border-radius: 12px !important;
        font-weight: 600 !important;
        font-size: 16px !important;
        padding: 14px 28px !important;
        color: white !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 4px 20px rgba(99, 102, 241, 0.3) !important;
    }
    
    .gr-button-primary:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 32px rgba(99, 102, 241, 0.4) !important;
        background: linear-gradient(45deg, #7c3aed, #a855f7) !important;
    }
    
    /* Input Fields */
    .gr-textbox, .gr-slider {
        background: rgba(30, 41, 59, 0.6) !important;
        border: 1px solid rgba(148, 163, 184, 0.3) !important;
        border-radius: 10px !important;
        color: #f1f5f9 !important;
    }
    
    /* Mobile Responsive Grid */
    @media (max-width: 768px) {
        .risk-card { margin: 8px 0 !important; }
        .dashboard-card { padding: 16px !important; margin: 12px 0 !important; }
        h1 { font-size: 2rem !important; }
        h2 { font-size: 1.5rem !important; }
    }
    
    /* Expandable Results */
    .results-container {
        background: rgba(30, 41, 59, 0.4) !important;
        border-radius: 12px !important;
        border: 1px solid rgba(148, 163, 184, 0.2) !important;
        max-height: 400px !important;
        overflow-y: auto !important;
        scrollbar-width: thin !important;
    }
    
    /* Custom Scrollbar */
    .results-container::-webkit-scrollbar {
        width: 8px !important;
    }
    
    .results-container::-webkit-scrollbar-track {
        background: rgba(30, 41, 59, 0.3) !important;
        border-radius: 4px !important;
    }
    
    .results-container::-webkit-scrollbar-thumb {
        background: rgba(99, 102, 241, 0.6) !important;
        border-radius: 4px !important;
    }
    
    /* Icons */
    .risk-icon {
        font-size: 2.5rem !important;
        margin-bottom: 12px !important;
        display: block !important;
    }
    
    /* Tooltips */
    .gr-tooltip {
        background: rgba(0, 0, 0, 0.9) !important;
        color: white !important;
        border-radius: 8px !important;
        padding: 8px 12px !important;
        font-size: 14px !important;
    }
    
    /* Labels and Info */
    .gr-label {
        color: #cbd5e1 !important;
        font-weight: 600 !important;
        font-size: 14px !important;
        margin-bottom: 8px !important;
    }
    
    .gr-info {
        color: #94a3b8 !important;
        font-size: 12px !important;
    }
    """
) as demo:
    
    gr.Markdown("""
<div class="dashboard-card">

# 🛡️ BrandGuard Enterprise
## Executive Brand Protection Dashboard

### **Real-time threat detection for M-Gas Kenya's digital assets**

**🎯 Mission:** Advanced AI-powered monitoring to identify Facebook impersonators, fake customer service accounts, and fraudulent schemes targeting your customers.

**📊 Intelligence:** Comprehensive risk analysis with automated evidence collection for legal action.

**⚖️ Compliance:** Full adherence to platform terms and data protection regulations.

</div>
""")
    
    with gr.Row():
        with gr.Column(scale=2):
            gr.Markdown("""
<div class="dashboard-card">

## 🎯 **Monitoring Configuration**

</div>
""")
            
            brand_terms = gr.Textbox(
                label="Brand Terms to Monitor",
                value="M-Gas, M Gas, M-Gas Kenya, mgas ke, mgas kenya",
                placeholder="Enter your brand names and variations...",
                lines=2,
                info="💡 Add variations of your brand name that impersonators might use"
            )
            
            search_intensity = gr.Slider(
                minimum=5,
                maximum=50,
                value=20,
                step=5,
                label="Scan Intensity",
                info="🔍 Higher values provide more comprehensive threat detection"
            )
            
            scan_btn = gr.Button("🚀 Launch Threat Detection Scan", variant="primary", size="lg")
        
        with gr.Column(scale=1):
            gr.Markdown("""
<div class="dashboard-card">

## 📊 **Brand Intelligence**

<div class="risk-card risk-total">
<span class="risk-icon">🏢</span>
<strong>M-Gas Kenya (Official)</strong><br>
✅ Verified Facebook Page<br>
👥 65,000+ Followers<br>
🌐 mgas.ke<br>
📞 0792 556677
</div>

### 🎯 **Threat Categories**
- 🚨 Fake customer service
- 💰 Fraudulent promotions  
- 🎭 Identity impersonation
- 📱 Unauthorized contact info

</div>
""")
    
    # Risk Status Cards
    gr.Markdown("""
<div class="dashboard-card">

## 📊 **Threat Level Dashboard**

</div>
""")
    
    with gr.Row():
        with gr.Column():
            high_risk_display = gr.Markdown("""
<div class="risk-card risk-high">
<span class="risk-icon">🚨</span>
<h3>Critical Threats</h3>
<div style="font-size: 2rem; font-weight: bold; color: #ef4444;">-</div>
<small>Immediate action required</small>
</div>
""")
        
        with gr.Column():
            medium_risk_display = gr.Markdown("""
<div class="risk-card risk-medium">
<span class="risk-icon">⚠️</span>
<h3>Suspicious Activity</h3>
<div style="font-size: 2rem; font-weight: bold; color: #f59e0b;">-</div>
<small>Enhanced monitoring</small>
</div>
""")
        
        with gr.Column():
            low_risk_display = gr.Markdown("""
<div class="risk-card risk-low">
<span class="risk-icon">ℹ️</span>
<h3>Low Priority</h3>
<div style="font-size: 2rem; font-weight: bold; color: #10b981;">-</div>
<small>Minimal business risk</small>
</div>
""")
            
        with gr.Column():
            total_display = gr.Markdown("""
<div class="risk-card risk-total">
<span class="risk-icon">📊</span>
<h3>Total Detected</h3>
<div style="font-size: 2rem; font-weight: bold; color: #3b82f6;">-</div>
<small>Brand mentions found</small>
</div>
""")
    
    with gr.Row():
        with gr.Column(scale=1):
            gr.Markdown("""
<div class="dashboard-card">

## 📈 **Executive Summary**

</div>
""")
            summary_output = gr.Textbox(
                label="Key Business Intelligence",
                lines=12,
                placeholder="Your executive summary will appear here...",
                info="📋 Strategic overview for leadership decisions",
                elem_classes=["results-container"]
            )
        
        with gr.Column(scale=1):
            gr.Markdown("""
<div class="dashboard-card">

## 🔍 **Detailed Analysis**

</div>
""")
            details_output = gr.Textbox(
                label="Individual Threat Assessments",
                lines=12,
                placeholder="Detailed threat analysis will appear here...",
                info="🎯 Complete risk profiles for enforcement teams",
                elem_classes=["results-container"]
            )
    
    status_output = gr.Textbox(
        label="📁 Report Generation Status",
        lines=3,
        placeholder="Professional report status will appear here...",
        info="📄 Evidence packages and legal documentation"
    )
    
    gr.Markdown("""
<div class="executive-card">

### 📋 Next Steps for High-Risk Threats

**For Immediate Action:**
- Review flagged entities with your legal team
- Document evidence for potential takedown requests  
- Coordinate with customer service on potential confusion
- Consider proactive customer communications

**Legal Process:**
- Generated reports include evidence packages
- All data collection follows platform compliance
- Ready for submission to Meta's reporting system
- Coordinate with intellectual property counsel

### 🛡️ Business Protection Benefits
✅ **Prevent Revenue Loss** - Stop fraudulent transactions  
✅ **Protect Customer Trust** - Identify fake support accounts  
✅ **Legal Evidence** - Professional documentation for enforcement  
✅ **Risk Management** - Early warning system for brand threats  

</div>
""")
    
    # Event Handler with Dynamic Card Updates
    scan_btn.click(
        fn=run_brandguard_scan,
        inputs=[brand_terms, search_intensity],
        outputs=[summary_output, details_output, status_output, 
                high_risk_display, medium_risk_display, low_risk_display, total_display]
    )

if __name__ == "__main__":
    import os
    import socket
    
    # Get port from environment or default to 5000
    port = int(os.environ.get("PORT", 5000))
    
    # Check if port is available
    def check_port(port):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.bind(("0.0.0.0", port))
            sock.close()
            return True
        except OSError:
            return False
    
    # Find available port if 5000 is occupied
    if not check_port(port):
        for test_port in range(5001, 5010):
            if check_port(test_port):
                port = test_port
                break
    
    try:
        # Launch with health check endpoint enabled
        demo.launch(
            server_name="0.0.0.0", 
            server_port=port, 
            share=False, 
            inbrowser=False,
            show_api=True,  # Enable API documentation for health checks
            max_threads=10  # Limit concurrent requests
        )
    except Exception as e:
        print(f"Failed to launch application: {e}")
        print(f"Port {port} may be in use. Try restarting the application.")
        exit(1)